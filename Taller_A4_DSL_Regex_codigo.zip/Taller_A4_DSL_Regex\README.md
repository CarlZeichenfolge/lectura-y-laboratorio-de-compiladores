# A4-LABORATORIO — DSL y Regex en Validación de Dataset

Solución completa del laboratorio sobre **PostgreSQL 16** (pgAdmin 4), con
implementación paralela en **Java** y **Python** que produce cifras idénticas.

---

## 1. Requisitos (ya instalados en este equipo)

| Componente | Versión | Nota |
|---|---|---|
| PostgreSQL | 16 | servicio `postgresql-x64-16`, puerto 5432 |
| Java (JDK) | 27 | permite ejecutar `.java` sin compilar previamente |
| Python | 3.12.10 | `C:\Users\carlo\AppData\Local\Programs\Python\Python312` |
| psycopg2-binary | 2.9.13 | driver de PostgreSQL para Python |
| openpyxl | 3.1.5 | escritura de archivos Excel |
| Driver JDBC | 42.7.4 | `lib/postgresql-42.7.4.jar` |

> **Use `py`, no `python`.** En este equipo la carpeta `WindowsApps` está en el
> `PATH` *de máquina*, que Windows evalúa antes que el de usuario, así que el
> alias de Microsoft Store intercepta `python` y responde *"Python was not
> found"* aunque Python sí esté instalado. El lanzador `py` resuelve
> correctamente. Para arreglarlo de raíz: Configuración → Aplicaciones →
> Configuración avanzada → Alias de ejecución de aplicaciones → desactive
> `python.exe` y `python3.exe`.

---

## 2. Antes de empezar: credenciales

Edite **`credenciales.env`** y ponga la contraseña real del usuario `postgres`:

```
PGPASSWORD=su_clave_real
```

Ese único archivo lo leen tanto `python/config.py` como `java/Conexion.java`.
Las variables de entorno (`PGPASSWORD`, etc.) tienen prioridad si prefiere no
escribirla en disco.

---

## 3. Orden de ejecución

### Paso 0 — Generar la tabla de personas *(ya ejecutado)*

```powershell
cd taller\java
java GenerarPersonas.java
```

Produce `data/persona_dataset.csv` con **1.263.988** personas.

**Por qué hace falta:** `pedidos_dataset.csv` referencia `Usuario_ID` entre 1 y
2.000.000, pero `dataset.csv` solo trae 20 personas — solo **18 pedidos de
2.000.000** casaban con un usuario existente. Sin este paso, la llave foránea y
el punto 4 del enunciado no tendrían sentido. El generador copia las 20 personas
originales **sin modificarlas** y crea una persona sintética por cada
`Usuario_ID` referenciado, reproduciendo la misma mezcla de errores de
`dataset.csv` (nombres en minúscula, correos sin dominio de primer nivel, edades
menores de 18). La semilla es fija, así que el resultado es reproducible.

### Paso 1 — Crear la base de datos y el esquema

En pgAdmin 4, `sql/01_esquema.sql`:

1. Conectado a **`postgres`**, ejecute el **bloque A** (`CREATE DATABASE`).
2. Refresque, conéctese a **`ubosquebd`** y ejecute el **bloque B** (las tablas).

### Paso 2 — Cargar los datos

```powershell
cd taller\python
py cargar_datos.py
```

Usa `COPY ... FROM STDIN`, que carga los 2 millones de filas en menos de un
minuto. No se usa `COPY FROM '<ruta>'` porque esa variante la ejecuta el
*servidor*, y la cuenta `NT AUTHORITY\NetworkService` bajo la que corre
PostgreSQL aquí no puede leer la carpeta Descargas.

### Paso 3 — Restricciones e índices

En pgAdmin, ejecute `sql/02_restricciones_indices.sql` sobre `ubosquebd`.
Aplica la llave foránea y los índices *después* de cargar (patrón estándar de
bulk-load) e incluye las consultas de verificación V1–V6, útiles como
evidencia gráfica para el informe.

### Paso 4 — Parte A (ejemplo base)

```powershell
cd taller\java
java -cp ..\lib\postgresql-42.7.4.jar AplMainDSL.java
```

```powershell
cd taller\python
py solucion_ejemplo.py
```

Ambos deben imprimir los **11 correos válidos** que muestra el PDF.

### Paso 5 — Partes B y C (actividades)

```powershell
cd taller\java
java -cp ..\lib\postgresql-42.7.4.jar AplPedidos.java
```

```powershell
cd taller\python
py solucion_pedidos.py
```

---

## 4. Qué produce cada ejecución

En `salidas/java/` y `salidas/python/`:

| Archivo | Punto del enunciado |
|---|---|
| `pedidos_validos.xlsx` | 2.e — válidos (**2 hojas**, supera el límite de Excel) |
| `pedidos_invalidos.xlsx` | 2.e — inválidos, con la columna `Motivo_Rechazo` |
| `pedidos_mas_de_2_unidades.xlsx` | 2.d — filtro dinámico del DSL |
| `pedidos_descartados_usuario_invalido.xlsx` | 4.b — descartados por persona inválida |
| `resumen_java.txt` / `resumen_python.txt` | 2.f, 2.g, 2.h |

---

## 5. Mapa de archivos

```
taller/
├── credenciales.env              <- EDITE ESTO
├── sql/
│   ├── 01_esquema.sql            base de datos + tablas
│   └── 02_restricciones_indices.sql  FK, índices y consultas de verificación
├── java/
│   ├── Conexion.java             configuración de conexión (lee credenciales.env)
│   ├── Reglas.java               las expresiones regulares, en un solo lugar
│   ├── DBQuery.java              DSL del ejemplo base (Parte A)
│   ├── AplMainDSL.java           programa de la Parte A
│   ├── PedidoDSL.java            DSL extendido para pedidos
│   ├── MiniXlsx.java             escritor .xlsx sin dependencias externas
│   ├── AplPedidos.java           programa de las Partes B y C
│   └── GenerarPersonas.java      utilidad de preparación de datos
├── python/
│   ├── config.py                 conexión + expresiones regulares
│   ├── cargar_datos.py           carga masiva con COPY
│   ├── solucion_ejemplo.py       Parte A
│   ├── pedido_dsl.py             DSL extendido para pedidos
│   ├── escritor_xlsx.py          Excel en streaming con corte de hojas
│   └── solucion_pedidos.py       Partes B y C
├── data/persona_dataset.csv      generado en el Paso 0
├── lib/postgresql-42.7.4.jar     driver JDBC
└── salidas/                      reportes
```

---

## 6. Resultados obtenidos

Todo lo que sigue proviene de una ejecución real y completa, y fue obtenido de
forma independiente por **cuatro** vías distintas —PowerShell sobre el CSV
crudo, Python, Java y el operador `~` de PostgreSQL— que coinciden hasta el
último dígito.

### Puntos 2.a, 2.b, 2.c, 2.f, 2.g, 2.h

```
Filas totales       = 2.000.000
Código válido       = 1.519.879   (75,99 %)
Producto válido     = 1.601.240   (80,06 %)
Cantidad válida     = 2.000.000   (100 %)
PEDIDOS VÁLIDOS     = 1.216.968   (60,85 %)
PEDIDOS INVÁLIDOS   =   783.032   (39,15 %)

Desglose de los inválidos (un pedido puede fallar varias reglas a la vez):
  código no cumple el patrón = 480.121
  producto mal escrito       = 398.760
  cantidad no positiva       =       0

Promedio de cantidad por pedido válido = 5,4985
  (suma de cantidades 6.691.472 / 1.216.968 pedidos válidos)
Producto más pedido = Cable HDMI (64.429 pedidos, 352.979 unidades)
```

> 480.121 + 398.760 = 878.881, que supera los 783.032 inválidos: la diferencia
> de 95.849 son pedidos que incumplen **las dos** reglas a la vez, típicamente
> `laptop35` / `laptop35_CODE`, donde el error del nombre se propaga al código.

### Punto 2.d — filtro dinámico del DSL

```
pedidos con cantidad > 2          = 1.599.302
de esos, además válidos por Regex =   973.029
```

### Punto 4 — cruce de validaciones

```
Pedidos válidos por Regex                  = 1.216.968
 ... cuya persona TAMBIÉN es válida (4.a)  =   853.039   (70,10 %)
 ... DESCARTADOS por persona inválida (4.b)=   363.929   (29,90 %)

Motivo del descarte:
  nombre no empieza en mayúscula = 169.784
  correo no cumple el patrón     = 170.204
  edad menor de 18               =  72.892
```

### Tiempos medidos

| Etapa | Tiempo |
|---|---|
| Carga de 1.263.988 personas (`COPY`) | 5,9 s |
| Carga de 2.000.000 pedidos (`COPY`) | 9,4 s |
| Partes B y C en **Java** | **31,7 s** |
| Partes B y C en **Python** | **460,4 s** |

La diferencia de casi 15× entre Java y Python está casi toda en la escritura de
los Excel: `openpyxl` construye un objeto por celda, mientras que `MiniXlsx`
serializa el XML directamente al ZIP. Es un dato interesante para comentar en
el informe.

### Tres detalles que conviene resaltar en el informe

1. **La validación de cantidad no rechaza nada.** Las 2.000.000 de cantidades
   están entre 1 y 10. La regla del punto 2.c es correcta, pero sobre este
   dataset su tasa de rechazo es 0. Vale la pena decirlo explícitamente en vez
   de dejar que parezca un descuido.

2. **"Cámara Web" nunca tiene código válido.** Los códigos se derivan de las tres
   primeras letras del producto en mayúscula, y para este producto eso da
   `CÁM-2024-M`. La `Á` acentuada no pertenece a `[A-Z]`, que solo cubre ASCII,
   así que *todos* sus pedidos se rechazan. Es el mejor ejemplo del dataset para
   la pregunta 3.a.

3. **Los válidos no caben en una hoja de Excel.** El límite es 1.048.576 filas y
   hay 1.216.968 válidos, por eso `pedidos_validos.xlsx` se parte en las hojas
   `Validos` y `Validos_2`, con el encabezado repetido.

### Material para las preguntas de reflexión

**3.a — ¿Por qué algunos códigos no cumplen el patrón?**
Se observan tres familias de defecto: (i) el código de respaldo
`<Producto>_CODE` (`SSD_CODE`, `Cable HDMI_CODE`), que usa guion bajo y espacios
en vez de la estructura `AAA-9999-A`; (ii) prefijos con vocal acentuada
(`CÁM-2024-M`), que fallan porque `[A-Z]` es un rango ASCII; y (iii) códigos
derivados de nombres ya defectuosos (`laptop35_CODE`), donde el error del nombre
se propaga al código.

**3.b — ¿Qué errores comunes aparecen en los nombres de productos?**
Predomina el nombre en minúscula con un número pegado al final
(`auriculares17`, `silla gamer49`, `teclado54`): dos infracciones a la vez, la
mayúscula inicial y la presencia de dígitos. Son 398.760 filas, casi el 20 % del
dataset.

**3.c — ¿Qué ventajas tiene Regex frente a condiciones tradicionales?**
Una sola expresión reemplaza una cadena de condiciones (longitud, posición de
los guiones, rango de cada carácter); la regla queda declarada en un único sitio
y es reutilizable en los tres motores; y es fácil de auditar. Su contrapartida
está a la vista en este mismo dataset: `[A-Z]` parecía significar "cualquier
letra mayúscula" y en realidad significa "las 26 mayúsculas ASCII", lo que
rechaza `CÁM` de forma silenciosa.
