import java.io.PrintStream;
import java.sql.Connection;
import java.util.List;

/**
 * PARTE A del laboratorio - ejemplo base desplegado sobre PostgreSQL.
 *
 * Reproduce la salida que muestra el enunciado en el paso 4: la lista de
 * correos que cumplen el patron ^[\w\.-]+@[\w\.-]+\.\w+$ entre las
 * personas mayores de 18 anios.
 *
 * Cambios frente al "Solution.java" entregado:
 *   1. El original se conectaba a SQLite ("jdbc:sqlite:empresa.db").
 *      Aqui se usa PostgreSQL a traves de la clase Conexion.
 *   2. El original consultaba la tabla "usuarios"; el esquema de este
 *      laboratorio la llama "persona".
 *   3. La clase publica se llamaba "Main"; el enunciado pide "AplMainDSL".
 *   4. La impresion salio del DSL y quedo aqui (ver DBQuery.execute()).
 *
 * Ejecucion:
 *     java -cp ..\lib\postgresql-42.7.4.jar AplMainDSL.java
 */
public class AplMainDSL {

    public static void main(String[] args) throws Exception {
        PrintStream out = new PrintStream(System.out, true, "UTF-8");

        out.println("======================================================");
        out.println(" PARTE A - Ejemplo base del DSL");
        out.println(" Conexion: " + Conexion.describir());
        out.println("======================================================");

        try (Connection conn = Conexion.abrir()) {

            // La condicion "id <= 20" acota la consulta a las 20 personas
            // del archivo dataset.csv, que son las del ejemplo del
            // enunciado. La tabla contiene ademas mas de un millon de
            // personas generadas para dar soporte a la llave foranea de
            // los 2.000.000 de pedidos (ver GenerarPersonas.java); sin
            // este filtro la salida no seria comparable con la del PDF.
            DBQuery consulta = new DBQuery(conn)
                    .from("persona")
                    .select("correo")
                    .whereAttr("edad", "> 18")
                    .whereAttr("id", "<= 20")
                    .validateWith("^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$");

            out.println("SQL generado por el DSL:");
            out.println("  " + consulta.sqlGenerado());
            out.println();

            List<String> validos = consulta.execute();

            for (String correo : validos) {
                out.println("Correo valido: " + correo);
            }

            out.println();
            out.println("Total de correos validos: " + validos.size());
        }
    }
}
