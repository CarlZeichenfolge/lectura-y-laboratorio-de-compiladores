import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PARTES B y C del laboratorio - solucion en Java sobre la tabla "pedidos".
 *
 * Resuelve, en este orden, los puntos de "ACTIVIDADES A DESARROLLAR":
 *
 *   2.a  validacion de codigos con Regex      ^[A-Z]{3}-[0-9]{4}-[A-Z]$
 *   2.b  validacion de nombres de producto    mayuscula inicial, letras y espacios
 *   2.c  validacion de cantidades             entero positivo
 *   2.d  filtro dinamico por el DSL           pedidos con mas de 2 unidades
 *   2.e  reportes en Excel                    validos e invalidos
 *   2.f  promedio de cantidad de los validos
 *   2.g  conteo de validos e invalidos
 *   2.h  producto mas pedido entre los validos
 *   4.a  cruce: solo personas correctas pueden tener pedidos validos
 *   4.b  reporte de pedidos descartados por persona invalida
 *
 * Ejecucion:
 *     java -cp ..\lib\postgresql-42.7.4.jar AplPedidos.java
 */
public class AplPedidos {

    static final Path DIR_SALIDA = Paths.get("..", "salidas", "java");

    static PrintStream out;

    public static void main(String[] args) throws Exception {
        out = new PrintStream(System.out, true, "UTF-8");
        Files.createDirectories(DIR_SALIDA);

        long inicio = System.nanoTime();
        titulo("PARTES B y C - Validacion de pedidos con DSL y Regex");
        out.println("  Conexion: " + Conexion.describir());
        out.println("  Salidas : " + DIR_SALIDA.toAbsolutePath().normalize());

        try (Connection conn = Conexion.abrir()) {
            Metricas m = recorridoPrincipal(conn);
            filtroMasDeDosUnidades(conn);
            informe(m);
            escribirResumen(m);
        }

        out.printf("%nTiempo total: %.1f s%n", (System.nanoTime() - inicio) / 1e9);
    }

    // =================================================================
    //  Acumulador de estadisticas
    // =================================================================
    static class Metricas {
        long total, validos, invalidos;
        long sumaCantidades;

        // Punto 2.g - desglose por regla incumplida
        long falloCodigo, falloProducto, falloCantidad;

        // Punto 4 - cruce con persona
        long validosConPersonaOk, descartadosPorPersona;
        long personaFalloNombre, personaFalloCorreo, personaFalloEdad;

        // Punto 2.h - histograma de productos entre los validos
        final Map<String, long[]> productos = new HashMap<>();  // [pedidos, unidades]

        void contarProducto(String nombre, int cantidad) {
            long[] acc = productos.computeIfAbsent(nombre, k -> new long[2]);
            acc[0]++;
            acc[1] += cantidad;
        }
    }

    // =================================================================
    //  Recorrido principal: una sola pasada sobre los 2.000.000 de filas
    // =================================================================
    static Metricas recorridoPrincipal(Connection conn) throws Exception {
        titulo("Recorrido principal (puntos 2.a, 2.b, 2.c, 2.e, 4.a, 4.b)");

        Metricas m = new Metricas();

        PedidoDSL dsl = new PedidoDSL(conn)
                .from("pedidos")
                .conPersona()                                  // punto 4
                .validate("codigo",   Reglas.CODIGO)           // punto 2.a
                .validate("producto", Reglas.PRODUCTO)         // punto 2.b
                .validate("cantidad", Reglas.CANTIDAD)         // punto 2.c
                .porLotesDe(20_000);

        out.println("  SQL generado por el DSL:");
        out.println("    " + dsl.sqlGenerado());
        out.println();

        String[] cab    = {"ID", "Usuario_ID", "Producto", "Cantidad", "Codigo"};
        String[] cabMal = {"ID", "Usuario_ID", "Producto", "Cantidad", "Codigo",
                           "Motivo_Rechazo"};
        String[] cabDesc = {"ID", "Usuario_ID", "Producto", "Cantidad", "Codigo",
                            "Nombre_Persona", "Correo_Persona", "Edad_Persona",
                            "Motivo_Persona"};

        try (MiniXlsx okXls   = new MiniXlsx(DIR_SALIDA.resolve("pedidos_validos.xlsx"),
                                             "Validos", cab);
             MiniXlsx malXls  = new MiniXlsx(DIR_SALIDA.resolve("pedidos_invalidos.xlsx"),
                                             "Invalidos", cabMal);
             MiniXlsx descXls = new MiniXlsx(
                     DIR_SALIDA.resolve("pedidos_descartados_usuario_invalido.xlsx"),
                     "Descartados", cabDesc)) {

            dsl.forEach(r -> {
                PedidoDSL.Pedido p = r.pedido();
                m.total++;

                if (r.esValido()) {
                    // ---- punto 2.e: reporte de validos ----------------
                    m.validos++;
                    m.sumaCantidades += p.cantidad();
                    m.contarProducto(p.producto(), p.cantidad());   // punto 2.h
                    okXls.fila(p.id(), p.usuarioId(), p.producto(),
                               p.cantidad(), p.codigo());

                    // ---- punto 4: cruce con la persona ---------------
                    if (Reglas.personaValida(p.personaNombre(), p.personaCorreo(),
                                             p.personaEdad())) {
                        m.validosConPersonaOk++;
                    } else {
                        m.descartadosPorPersona++;
                        String motivo = Reglas.motivoPersona(
                                p.personaNombre(), p.personaCorreo(), p.personaEdad());
                        if (motivo.contains("nombre")) m.personaFalloNombre++;
                        if (motivo.contains("correo")) m.personaFalloCorreo++;
                        if (motivo.contains("edad"))   m.personaFalloEdad++;
                        descXls.fila(p.id(), p.usuarioId(), p.producto(),
                                     p.cantidad(), p.codigo(),
                                     p.personaNombre(), p.personaCorreo(),
                                     p.personaEdad(), motivo);
                    }
                } else {
                    // ---- punto 2.e: reporte de invalidos --------------
                    m.invalidos++;
                    if (r.errores().contains("codigo"))   m.falloCodigo++;
                    if (r.errores().contains("producto")) m.falloProducto++;
                    if (r.errores().contains("cantidad")) m.falloCantidad++;
                    malXls.fila(p.id(), p.usuarioId(), p.producto(),
                                p.cantidad(), p.codigo(), r.motivos());
                }

                if (m.total % 250_000 == 0) {
                    out.printf("    procesados %,d ...%n", m.total);
                }
            });

            out.printf("%n  pedidos_validos.xlsx                        -> %,d filas en %d hoja(s)%n",
                       okXls.filasEscritas(), okXls.hojasUsadas());
            out.printf("  pedidos_invalidos.xlsx                      -> %,d filas en %d hoja(s)%n",
                       malXls.filasEscritas(), malXls.hojasUsadas());
            out.printf("  pedidos_descartados_usuario_invalido.xlsx   -> %,d filas en %d hoja(s)%n",
                       descXls.filasEscritas(), descXls.hojasUsadas());
        }
        return m;
    }

    // =================================================================
    //  Punto 2.d - filtro dinamico con el DSL
    // =================================================================
    static void filtroMasDeDosUnidades(Connection conn) throws Exception {
        titulo("Punto 2.d - filtro dinamico: pedidos con mas de 2 unidades");

        // La condicion NO esta escrita en el SQL: la genera whereAttr() en
        // tiempo de ejecucion a partir del nombre del atributo y del
        // operador. Eso es la metaprogramacion que pide el enunciado.
        PedidoDSL dsl = new PedidoDSL(conn)
                .from("pedidos")
                .whereAttr("cantidad", "> 2")
                .validate("codigo",   Reglas.CODIGO)
                .validate("producto", Reglas.PRODUCTO)
                .validate("cantidad", Reglas.CANTIDAD)
                .porLotesDe(20_000);

        out.println("  SQL generado por el DSL:");
        out.println("    " + dsl.sqlGenerado());
        out.println();

        long[] cont = new long[2];   // [0]=leidos con cantidad>2, [1]=ademas validos
        List<String> muestra = new ArrayList<>(10);

        try (MiniXlsx xls = new MiniXlsx(
                DIR_SALIDA.resolve("pedidos_mas_de_2_unidades.xlsx"),
                "MasDe2Unidades",
                "ID", "Usuario_ID", "Producto", "Cantidad", "Codigo")) {

            dsl.forEach(r -> {
                cont[0]++;
                if (!r.esValido()) return;
                cont[1]++;
                PedidoDSL.Pedido p = r.pedido();
                xls.fila(p.id(), p.usuarioId(), p.producto(), p.cantidad(), p.codigo());
                if (muestra.size() < 10) {
                    muestra.add(String.format("    %-8d %-14s %2d  %s",
                            p.id(), p.producto(), p.cantidad(), p.codigo()));
                }
            });

            out.printf("  pedidos con cantidad > 2            : %,d%n", cont[0]);
            out.printf("  de esos, ademas validos por Regex   : %,d%n", cont[1]);
            out.printf("  pedidos_mas_de_2_unidades.xlsx      -> %,d filas en %d hoja(s)%n",
                       xls.filasEscritas(), xls.hojasUsadas());
        }

        out.println();
        out.println("  Primeros 10 del listado:");
        out.printf("    %-8s %-14s %2s  %s%n", "ID", "PRODUCTO", "CT", "CODIGO");
        muestra.forEach(out::println);
    }

    // =================================================================
    //  Informe por consola (puntos 2.f, 2.g, 2.h y 4)
    // =================================================================
    static void informe(Metricas m) {
        titulo("Puntos 2.f, 2.g, 2.h - estadisticas");

        out.printf("  Total de pedidos procesados : %,d%n", m.total);
        out.printf("  Pedidos VALIDOS             : %,d  (%.2f %%)%n",
                   m.validos, pct(m.validos, m.total));
        out.printf("  Pedidos INVALIDOS           : %,d  (%.2f %%)%n",
                   m.invalidos, pct(m.invalidos, m.total));
        out.println();
        out.println("  Desglose de los invalidos (un pedido puede fallar varias reglas):");
        out.printf("    codigo no cumple el patron   : %,d%n", m.falloCodigo);
        out.printf("    producto mal escrito         : %,d%n", m.falloProducto);
        out.printf("    cantidad no positiva         : %,d%n", m.falloCantidad);
        out.println();

        double promedio = m.validos == 0 ? 0 : (double) m.sumaCantidades / m.validos;
        out.printf("  Promedio de cantidad por pedido valido : %.4f%n", promedio);
        out.printf("  (suma de cantidades = %,d  /  pedidos validos = %,d)%n",
                   m.sumaCantidades, m.validos);
        out.println();

        out.println("  Punto 2.h - productos mas pedidos entre los validos:");
        out.printf("    %-14s %12s %12s%n", "PRODUCTO", "PEDIDOS", "UNIDADES");
        List<Map.Entry<String, long[]>> orden = new ArrayList<>(m.productos.entrySet());
        orden.sort(Comparator.comparingLong((Map.Entry<String, long[]> e) -> e.getValue()[0])
                             .reversed());
        for (int i = 0; i < Math.min(10, orden.size()); i++) {
            Map.Entry<String, long[]> e = orden.get(i);
            out.printf("    %-14s %,12d %,12d%n", e.getKey(), e.getValue()[0], e.getValue()[1]);
        }
        if (!orden.isEmpty()) {
            Map.Entry<String, long[]> top = orden.get(0);
            out.println();
            out.printf("  >> PRODUCTO MAS PEDIDO: %s  (%,d pedidos, %,d unidades)%n",
                       top.getKey(), top.getValue()[0], top.getValue()[1]);
        }

        titulo("Punto 4 - cruce de validaciones pedidos <-> persona");
        out.printf("  Pedidos validos por Regex                     : %,d%n", m.validos);
        out.printf("  ... cuya persona TAMBIEN es valida (4.a)      : %,d  (%.2f %%)%n",
                   m.validosConPersonaOk, pct(m.validosConPersonaOk, m.validos));
        out.printf("  ... DESCARTADOS por persona invalida (4.b)    : %,d  (%.2f %%)%n",
                   m.descartadosPorPersona, pct(m.descartadosPorPersona, m.validos));
        out.println();
        out.println("  Motivo del descarte (la persona puede fallar en varios campos):");
        out.printf("    nombre no empieza en mayuscula : %,d%n", m.personaFalloNombre);
        out.printf("    correo no cumple el patron     : %,d%n", m.personaFalloCorreo);
        out.printf("    edad menor de %d                : %,d%n",
                   Reglas.EDAD_MINIMA, m.personaFalloEdad);
    }

    // =================================================================
    //  Resumen en archivo de texto
    // =================================================================
    static void escribirResumen(Metricas m) throws Exception {
        List<Map.Entry<String, long[]>> orden = new ArrayList<>(m.productos.entrySet());
        orden.sort(Comparator.comparingLong((Map.Entry<String, long[]> e) -> e.getValue()[0])
                             .reversed());

        StringBuilder sb = new StringBuilder(2048);
        sb.append("RESUMEN DE VALIDACION - SOLUCION EN JAVA\n");
        sb.append("========================================\n\n");
        sb.append("Regex de codigo   : ").append(Reglas.CODIGO).append('\n');
        sb.append("Regex de producto : ").append(Reglas.PRODUCTO).append('\n');
        sb.append("Regex de cantidad : ").append(Reglas.CANTIDAD).append('\n');
        sb.append("Regex de correo   : ").append(Reglas.CORREO).append("\n\n");
        sb.append(String.format("Total de pedidos    : %,d%n", m.total));
        sb.append(String.format("Pedidos validos     : %,d (%.2f %%)%n",
                  m.validos, pct(m.validos, m.total)));
        sb.append(String.format("Pedidos invalidos   : %,d (%.2f %%)%n",
                  m.invalidos, pct(m.invalidos, m.total)));
        sb.append(String.format("  fallo codigo      : %,d%n", m.falloCodigo));
        sb.append(String.format("  fallo producto    : %,d%n", m.falloProducto));
        sb.append(String.format("  fallo cantidad    : %,d%n", m.falloCantidad));
        sb.append(String.format("Promedio cantidad   : %.4f%n",
                  m.validos == 0 ? 0 : (double) m.sumaCantidades / m.validos));
        if (!orden.isEmpty()) {
            sb.append(String.format("Producto mas pedido : %s (%,d pedidos)%n",
                      orden.get(0).getKey(), orden.get(0).getValue()[0]));
        }
        sb.append(String.format("%nPunto 4 - cruce con persona%n"));
        sb.append(String.format("  validos con persona OK : %,d%n", m.validosConPersonaOk));
        sb.append(String.format("  descartados            : %,d%n", m.descartadosPorPersona));
        sb.append(String.format("    por nombre           : %,d%n", m.personaFalloNombre));
        sb.append(String.format("    por correo           : %,d%n", m.personaFalloCorreo));
        sb.append(String.format("    por edad             : %,d%n", m.personaFalloEdad));

        sb.append("\nProductos entre los validos (pedidos / unidades)\n");
        for (Map.Entry<String, long[]> e : orden) {
            sb.append(String.format("  %-14s %,10d %,12d%n",
                      e.getKey(), e.getValue()[0], e.getValue()[1]));
        }

        Path destino = DIR_SALIDA.resolve("resumen_java.txt");
        Files.writeString(destino, sb.toString(), StandardCharsets.UTF_8);
        out.println();
        out.println("  Resumen escrito en: " + destino.toAbsolutePath().normalize());
    }

    // =================================================================
    static double pct(long parte, long total) {
        return total == 0 ? 0 : 100.0 * parte / total;
    }

    static void titulo(String texto) {
        out.println();
        out.println("======================================================================");
        out.println(" " + texto);
        out.println("======================================================================");
    }
}
