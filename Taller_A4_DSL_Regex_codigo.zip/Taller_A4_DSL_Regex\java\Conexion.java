import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Punto unico de configuracion de la conexion a PostgreSQL, compartido
 * por AplMainDSL y AplPedidos.
 *
 * Los datos se toman, en este orden de prioridad:
 *   1. variables de entorno (PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD)
 *   2. el archivo taller/credenciales.env
 *   3. los valores por defecto de una instalacion tipica
 *
 * Es el mismo archivo que lee python/config.py, para no tener que
 * escribir la contrasenia en dos lenguajes distintos.
 */
public final class Conexion {

    private static final Path ARCHIVO_CREDENCIALES =
            Paths.get("..", "credenciales.env");

    private static final Map<String, String> ARCHIVO = leerArchivo();

    private static final String HOST     = cfg("PGHOST",     "localhost");
    private static final String PORT     = cfg("PGPORT",     "5432");
    private static final String DATABASE = cfg("PGDATABASE", "ubosquebd");
    private static final String USER     = cfg("PGUSER",     "postgres");
    private static final String PASSWORD = cfg("PGPASSWORD", "postgres");

    public static final String URL =
            "jdbc:postgresql://" + HOST + ":" + PORT + "/" + DATABASE;

    private Conexion() { }

    public static Connection abrir() throws SQLException {
        Connection c = DriverManager.getConnection(URL, USER, PASSWORD);
        c.setAutoCommit(true);
        return c;
    }

    public static String describir() {
        return USER + "@" + HOST + ":" + PORT + "/" + DATABASE;
    }

    /** Prioridad: variable de entorno > credenciales.env > valor por defecto. */
    private static String cfg(String clave, String porDefecto) {
        String env = System.getenv(clave);
        if (env != null && !env.isBlank()) return env;
        String arch = ARCHIVO.get(clave);
        if (arch != null && !arch.isBlank()) return arch;
        return porDefecto;
    }

    /** Lee un archivo simple de pares CLAVE=VALOR, ignorando comentarios. */
    private static Map<String, String> leerArchivo() {
        Map<String, String> valores = new HashMap<>();
        try {
            if (!Files.exists(ARCHIVO_CREDENCIALES)) return valores;
            for (String linea : Files.readAllLines(ARCHIVO_CREDENCIALES,
                                                   StandardCharsets.UTF_8)) {
                String l = linea.trim();
                int igual = l.indexOf('=');
                if (l.isEmpty() || l.startsWith("#") || igual < 0) continue;
                valores.put(l.substring(0, igual).trim(),
                            l.substring(igual + 1).trim());
            }
        } catch (IOException e) {
            System.err.println("Aviso: no se pudo leer credenciales.env ("
                             + e.getMessage() + "); se usaran los valores por defecto.");
        }
        return valores;
    }
}
