import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * DSL INTERNO para consultar una tabla y validar el resultado con Regex.
 *
 * Es la version corregida del "Solution.java" que entrega el enunciado y
 * sobre el que se advierte que "tiene un mal diseno". Los defectos
 * detectados y su correccion estan documentados en cada metodo.
 *
 * Tecnicas de DSL que implementa:
 *   - Method chaining / fluent interface : cada metodo devuelve "this",
 *     lo que permite encadenar las llamadas y leer la consulta como una
 *     frase en lugar de como SQL.
 *   - Metaprogramacion : whereAttr() construye la clausula WHERE en
 *     tiempo de ejecucion a partir del nombre de un atributo y un
 *     operador, sin que la condicion este escrita en el codigo fuente.
 *   - Procesamiento de colecciones : execute() filtra el ResultSet con
 *     el Pattern antes de devolverlo.
 */
public class DBQuery {

    /**
     * Un identificador SQL legitimo: letras, digitos y guion bajo, sin
     * empezar por digito. Se usa para blindar from() y select(), que
     * concatenan texto directamente en la sentencia.
     */
    private static final Pattern IDENTIFICADOR =
            Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*$");

    /**
     * Un operador de comparacion seguido de un literal numerico:
     * "> 18", ">=3", "= 10", "<> 0". Impide que por whereAttr() entre
     * algo como "0 OR 1=1; DROP TABLE persona".
     */
    private static final Pattern OPERADOR =
            Pattern.compile("^(=|<>|!=|<|<=|>|>=)\\s*-?\\d+$");

    private final Connection conn;
    private String tabla;
    private String campo;
    private final List<String> condiciones = new ArrayList<>();
    private Pattern regex;

    public DBQuery(Connection conn) {
        if (conn == null) {
            throw new IllegalArgumentException("La conexion no puede ser nula");
        }
        this.conn = conn;
    }

    // ---------------------------------------------------------------
    // Interfaz fluida
    // ---------------------------------------------------------------

    /**
     * DEFECTO 1 del original: el nombre de la tabla se concatenaba en el
     * SQL sin ninguna comprobacion, lo que abre la puerta a inyeccion.
     */
    public DBQuery from(String tabla) {
        exigirIdentificador(tabla, "tabla");
        this.tabla = tabla;
        return this;
    }

    public DBQuery select(String campo) {
        exigirIdentificador(campo, "campo");
        this.campo = campo;
        return this;
    }

    /**
     * Metaprogramacion: arma la condicion WHERE en ejecucion.
     *
     * DEFECTO 2 del original: aceptaba cualquier cadena como operador.
     * Aqui se valida con Regex, que es precisamente el tema del
     * laboratorio: la misma herramienta que valida los datos sirve para
     * validar el codigo que el DSL genera.
     *
     * DEFECTO 3 del original: solo admitia UNA condicion; una segunda
     * llamada pisaba la anterior en silencio. Ahora se acumulan y se
     * unen con AND, que es el comportamiento que un usuario del DSL
     * espera al encadenar.
     */
    public DBQuery whereAttr(String atributo, String operador) {
        exigirIdentificador(atributo, "atributo");
        String op = operador == null ? "" : operador.trim();
        if (!OPERADOR.matcher(op).matches()) {
            throw new IllegalArgumentException(
                "Operador no permitido: \"" + operador + "\". " +
                "Se espera algo como \"> 18\" o \">= 3\".");
        }
        this.condiciones.add(atributo + " " + op);
        return this;
    }

    public DBQuery validateWith(String patron) {
        this.regex = Pattern.compile(patron);
        return this;
    }

    // ---------------------------------------------------------------
    // Ejecucion
    // ---------------------------------------------------------------

    /**
     * DEFECTO 4 del original: execute() imprimia "Correo valido: ..."
     * directamente por pantalla. Eso amarra el DSL a un unico caso de
     * uso y a un unico formato de salida. Ahora devuelve la coleccion y
     * es quien llama el que decide que hacer con ella.
     *
     * DEFECTO 5 del original: Statement y ResultSet nunca se cerraban
     * (fuga de recursos). Se resuelve con try-with-resources.
     *
     * DEFECTO 6 del original: rs.getString(field) falla si el campo
     * lleva alias o calificador; se usa el indice de columna.
     *
     * DEFECTO 7 del original: "catch (Exception e) { e.printStackTrace(); }"
     * se tragaba el error y devolvia como si todo hubiera salido bien.
     * Ahora la SQLException se propaga.
     *
     * DEFECTO 8 del original: usaba matcher.matches() sobre un valor que
     * podia ser NULL, lanzando NullPointerException.
     */
    public List<String> execute() throws SQLException {
        if (tabla == null || campo == null) {
            throw new IllegalStateException(
                "Falta invocar from() y/o select() antes de execute()");
        }

        List<String> resultados = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sqlGenerado())) {
            while (rs.next()) {
                String valor = rs.getString(1);
                if (valor == null) continue;
                if (regex == null || regex.matcher(valor).matches()) {
                    resultados.add(valor);
                }
            }
        }
        return resultados;
    }

    /** Devuelve el SQL que el DSL genero. Util para las evidencias. */
    public String sqlGenerado() {
        return "SELECT " + campo + " FROM " + tabla
             + (condiciones.isEmpty() ? "" : " WHERE " + String.join(" AND ", condiciones))
             + " ORDER BY " + campo;
    }

    private static void exigirIdentificador(String valor, String rol) {
        if (valor == null || !IDENTIFICADOR.matcher(valor).matches()) {
            throw new IllegalArgumentException(
                "Nombre de " + rol + " no valido: \"" + valor + "\"");
        }
    }
}
