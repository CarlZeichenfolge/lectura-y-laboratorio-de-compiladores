import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.Normalizer;
import java.util.BitSet;
import java.util.Random;

/**
 * UTILIDAD DE PREPARACION DE DATOS (no hace parte del DSL).
 *
 * Problema que resuelve: el archivo "pedidos_dataset.csv" referencia Usuario_ID
 * en el rango 1..2.000.000, pero "dataset.csv" solo trae 20 personas. Solo 18
 * pedidos de 2.000.000 casan con una persona existente, por lo que la llave
 * foranea y el punto 4 del laboratorio (cruce de validaciones) no tendrian
 * sentido con los datos tal como se entregan.
 *
 * Este generador construye "persona_dataset.csv" con:
 *   1. Las 20 personas originales de dataset.csv, copiadas sin modificacion.
 *   2. Una persona sintetica por cada Usuario_ID distinto referenciado en
 *      pedidos_dataset.csv que no este entre esos 20.
 *
 * Los datos sinteticos reproducen a proposito la misma mezcla de errores que
 * trae dataset.csv (nombres en minuscula, correos sin dominio de primer nivel,
 * edades menores de 18), para que el cruce de validaciones arroje resultados
 * significativos. La semilla es fija, asi que el resultado es reproducible.
 *
 * Uso:  java GenerarPersonas.java
 */
public class GenerarPersonas {

    static final Path DIR_ORIGEN  = Paths.get("..", "..", "LABCLASES");
    static final Path CSV_PEDIDOS = DIR_ORIGEN.resolve("pedidos_dataset.csv");
    static final Path CSV_BASE    = DIR_ORIGEN.resolve("dataset.csv");
    static final Path CSV_SALIDA  = Paths.get("..", "data", "persona_dataset.csv");

    static final long SEMILLA = 2026L;

    static final String[] NOMBRES = {
        "Ana", "Luis", "Pedro", "Maria", "Juan", "Carolina", "Andres", "Sofia",
        "Miguel", "Laura", "Jose", "Claudia", "Felipe", "Camila", "Ricardo",
        "Valentina", "Daniel", "Esteban", "Natalia", "Fernanda", "Alejandro",
        "Paula", "Santiago", "Manuela", "Sebastian", "Isabella", "Mateo",
        "Gabriela", "Nicolas", "Juliana", "Tomas", "Antonia", "Emilio", "Renata"
    };

    /** Dominios que SI cumplen ^[\w\.-]+@[\w\.-]+\.\w+$ */
    static final String[] DOMINIOS_OK = {
        "example.com", "empresa.com", "gmail.com", "hotmail.com",
        "outlook.com", "dominio.net", "empresa.co"
    };

    /** Dominios sin punto: NO cumplen el patron (igual que "pedro@correo") */
    static final String[] DOMINIOS_MAL = { "correo", "empresa", "dominio" };

    public static void main(String[] args) throws Exception {
        PrintStream out = new PrintStream(System.out, true, "UTF-8");

        if (!Files.exists(CSV_PEDIDOS)) {
            out.println("ERROR: no se encontro " + CSV_PEDIDOS.toAbsolutePath());
            return;
        }
        Files.createDirectories(CSV_SALIDA.getParent());

        // --- Paso 1: recolectar los Usuario_ID distintos -------------------
        out.println("Leyendo " + CSV_PEDIDOS.getFileName() + " ...");
        BitSet referenciados = new BitSet();
        int maxId = 0;
        long filas = 0;

        try (BufferedReader br = Files.newBufferedReader(CSV_PEDIDOS, StandardCharsets.UTF_8)) {
            br.readLine(); // encabezado
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.isEmpty()) continue;
                int c1 = linea.indexOf(',');
                if (c1 < 0) continue;
                int c2 = linea.indexOf(',', c1 + 1);
                if (c2 < 0) continue;
                int id;
                try {
                    id = Integer.parseInt(linea.substring(c1 + 1, c2).trim());
                } catch (NumberFormatException e) {
                    continue;
                }
                if (id > 0) {
                    referenciados.set(id);
                    if (id > maxId) maxId = id;
                }
                filas++;
            }
        }
        out.printf("  pedidos leidos      = %,d%n", filas);
        out.printf("  usuarios distintos  = %,d%n", referenciados.cardinality());
        out.printf("  Usuario_ID maximo   = %,d%n", maxId);

        // --- Paso 2: escribir el CSV de personas ---------------------------
        Random rnd = new Random(SEMILLA);
        int copiadas = 0, generadas = 0;

        try (BufferedWriter bw = Files.newBufferedWriter(CSV_SALIDA, StandardCharsets.UTF_8);
             BufferedReader base = Files.newBufferedReader(CSV_BASE, StandardCharsets.UTF_8)) {

            bw.write("id,nombre,correo,edad");
            bw.newLine();

            // 2a. las 20 personas originales, tal cual vienen
            base.readLine(); // encabezado
            String linea;
            while ((linea = base.readLine()) != null) {
                if (linea.isBlank()) continue;
                bw.write(linea.trim());
                bw.newLine();
                copiadas++;
                int id = Integer.parseInt(linea.substring(0, linea.indexOf(',')).trim());
                referenciados.clear(id); // ya quedo escrita, no regenerar
            }

            // 2b. una persona sintetica por cada Usuario_ID restante
            for (int id = referenciados.nextSetBit(0); id >= 0;
                     id = referenciados.nextSetBit(id + 1)) {
                bw.write(construirPersona(id, rnd));
                bw.newLine();
                generadas++;
            }
        }

        out.println();
        out.println("Archivo generado: " + CSV_SALIDA.toAbsolutePath().normalize());
        out.printf("  personas copiadas de dataset.csv = %,d%n", copiadas);
        out.printf("  personas generadas               = %,d%n", generadas);
        out.printf("  TOTAL en persona_dataset.csv     = %,d%n", copiadas + generadas);
    }

    /**
     * Construye una fila "id,nombre,correo,edad" inyectando errores segun la
     * misma distribucion de defectos que exhibe dataset.csv.
     */
    static String construirPersona(int id, Random rnd) {
        String nombre = NOMBRES[rnd.nextInt(NOMBRES.length)];
        int edad = 18 + rnd.nextInt(53);            // 18..70  -> valida
        String dominio = DOMINIOS_OK[rnd.nextInt(DOMINIOS_OK.length)];

        int dado = rnd.nextInt(100);
        if (dado < 70) {
            // 70% completamente valida
        } else if (dado < 80) {
            nombre = nombre.toLowerCase();          // 10% nombre en minuscula
        } else if (dado < 90) {
            dominio = DOMINIOS_MAL[rnd.nextInt(DOMINIOS_MAL.length)];  // 10% correo sin TLD
        } else if (dado < 96) {
            edad = 10 + rnd.nextInt(8);             // 6% menor de edad (10..17)
        } else {
            nombre = nombre.toLowerCase();          // 4% dos defectos a la vez
            dominio = DOMINIOS_MAL[rnd.nextInt(DOMINIOS_MAL.length)];
        }

        String correo = sinTildes(nombre).toLowerCase() + id + "@" + dominio;
        return id + "," + nombre + "," + correo + "," + edad;
    }

    static String sinTildes(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD)
                         .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
}
