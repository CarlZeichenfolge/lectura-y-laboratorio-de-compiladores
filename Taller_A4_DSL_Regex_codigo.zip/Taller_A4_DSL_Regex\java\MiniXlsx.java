import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Escritor de archivos .xlsx en streaming y SIN DEPENDENCIAS EXTERNAS.
 *
 * POR QUE NO SE USA APACHE POI
 * ----------------------------
 * El equipo no tiene Maven ni Gradle instalados, asi que agregar POI
 * obligaria a descargar y encadenar a mano media docena de JAR. Un
 * archivo .xlsx es, en realidad, un ZIP que contiene documentos XML
 * (formato OOXML / SpreadsheetML), y tanto java.util.zip como la
 * escritura de XML son parte de la biblioteca estandar de Java. Esta
 * clase escribe ese ZIP directamente.
 *
 * POR QUE EN STREAMING
 * --------------------
 * El reporte de pedidos validos tiene mas de 1.2 millones de filas.
 * Construirlas en memoria como objetos antes de guardar agota el heap.
 * Aqui cada fila se serializa y se comprime en el momento, de modo que
 * el consumo de memoria es constante sin importar cuantas filas haya.
 *
 * LIMITE DE FILAS DE EXCEL
 * ------------------------
 * Una hoja de calculo admite como maximo 1.048.576 filas, encabezado
 * incluido. Como los pedidos validos superan esa cifra, la clase abre
 * automaticamente una hoja nueva ("Validos_2", "Validos_3", ...) y le
 * repite el encabezado cuando la hoja en curso se llena.
 *
 * Uso:
 *     try (MiniXlsx x = new MiniXlsx(ruta, "Validos", encabezados)) {
 *         x.fila(1, "Laptop", 5, "LAP-2026-A");
 *     }
 */
public class MiniXlsx implements Closeable {

    /** Maximo de filas por hoja en Excel, encabezado incluido. */
    public static final int MAX_FILAS_HOJA = 1_048_576;

    private static final String NS_MAIN =
            "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static final String NS_REL =
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static final String NS_PKG_REL =
            "http://schemas.openxmlformats.org/package/2006/relationships";
    private static final String NS_CT =
            "http://schemas.openxmlformats.org/package/2006/content-types";

    private final ZipOutputStream zip;
    private final String nombreBase;
    private final String[] encabezados;
    private final List<String> hojas = new ArrayList<>();

    private Writer hoja;          // escritor de la hoja en curso
    private int filaActual;       // 1-based, incluye el encabezado
    private long filasEscritas;   // total de filas de datos
    private boolean cerrado;

    public MiniXlsx(Path destino, String nombreHoja, String... encabezados)
            throws IOException {
        Files.createDirectories(destino.toAbsolutePath().getParent());
        this.zip = new ZipOutputStream(
                Files.newOutputStream(destino), StandardCharsets.UTF_8);
        // Nivel 1: el XML de una hoja de calculo comprime muy bien, y con
        // millones de filas la velocidad importa mas que el ultimo byte.
        this.zip.setLevel(Deflater.BEST_SPEED);
        this.nombreBase  = sanearNombreHoja(nombreHoja);
        this.encabezados = encabezados.clone();
        abrirHoja();
    }

    // ---------------------------------------------------------------
    // API publica
    // ---------------------------------------------------------------

    /**
     * Escribe una fila. Los valores Number se guardan como numero (para
     * que Excel pueda sumarlos y promediarlos); el resto, como texto.
     */
    public void fila(Object... valores) throws IOException {
        if (filaActual >= MAX_FILAS_HOJA) {
            cerrarHoja();
            abrirHoja();
        }
        filaActual++;
        escribirFila(valores);
        filasEscritas++;
    }

    public long filasEscritas() { return filasEscritas; }

    public int hojasUsadas() { return hojas.size(); }

    @Override
    public void close() throws IOException {
        if (cerrado) return;
        cerrado = true;
        cerrarHoja();
        escribirContentTypes();
        escribirRelsRaiz();
        escribirWorkbook();
        escribirWorkbookRels();
        escribirStyles();
        zip.close();
    }

    // ---------------------------------------------------------------
    // Manejo de hojas
    // ---------------------------------------------------------------

    private void abrirHoja() throws IOException {
        int n = hojas.size() + 1;
        hojas.add(n == 1 ? nombreBase : sanearNombreHoja(nombreBase + "_" + n));

        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet" + n + ".xml"));
        hoja = new BufferedWriter(
                new OutputStreamWriter(zip, StandardCharsets.UTF_8), 1 << 16);
        hoja.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        hoja.write("<worksheet xmlns=\"" + NS_MAIN + "\"><sheetData>");

        filaActual = 0;
        if (encabezados.length > 0) {
            filaActual++;
            escribirFila((Object[]) encabezados);
        }
    }

    private void cerrarHoja() throws IOException {
        if (hoja == null) return;
        hoja.write("</sheetData></worksheet>");
        hoja.flush();          // vuelca al ZipOutputStream...
        zip.closeEntry();      // ...y cierra la entrada, sin cerrar el ZIP
        hoja = null;
    }

    private void escribirFila(Object[] valores) throws IOException {
        hoja.write("<row r=\"");
        hoja.write(Integer.toString(filaActual));
        hoja.write("\">");
        for (int c = 0; c < valores.length; c++) {
            Object v = valores[c];
            String ref = columna(c) + filaActual;
            if (v == null) {
                continue;                      // celda vacia: se omite
            }
            if (v instanceof Number) {
                hoja.write("<c r=\"" + ref + "\"><v>");
                hoja.write(v.toString());
                hoja.write("</v></c>");
            } else {
                hoja.write("<c r=\"" + ref + "\" t=\"inlineStr\"><is><t xml:space=\"preserve\">");
                escaparXml(v.toString(), hoja);
                hoja.write("</t></is></c>");
            }
        }
        hoja.write("</row>");
    }

    // ---------------------------------------------------------------
    // Partes fijas del paquete OOXML
    // ---------------------------------------------------------------

    private void escribirContentTypes() throws IOException {
        StringBuilder sb = new StringBuilder(512);
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
          .append("<Types xmlns=\"").append(NS_CT).append("\">")
          .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
          .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
          .append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
          .append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for (int i = 1; i <= hojas.size(); i++) {
            sb.append("<Override PartName=\"/xl/worksheets/sheet").append(i)
              .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        }
        sb.append("</Types>");
        entrada("[Content_Types].xml", sb.toString());
    }

    private void escribirRelsRaiz() throws IOException {
        entrada("_rels/.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
          + "<Relationships xmlns=\"" + NS_PKG_REL + "\">"
          + "<Relationship Id=\"rId1\" Type=\"" + NS_REL + "/officeDocument\" Target=\"xl/workbook.xml\"/>"
          + "</Relationships>");
    }

    private void escribirWorkbook() throws IOException {
        StringBuilder sb = new StringBuilder(256);
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
          .append("<workbook xmlns=\"").append(NS_MAIN)
          .append("\" xmlns:r=\"").append(NS_REL).append("\"><sheets>");
        for (int i = 1; i <= hojas.size(); i++) {
            sb.append("<sheet name=\"");
            escaparXml(hojas.get(i - 1), sb);
            sb.append("\" sheetId=\"").append(i).append("\" r:id=\"rId").append(i).append("\"/>");
        }
        sb.append("</sheets></workbook>");
        entrada("xl/workbook.xml", sb.toString());
    }

    private void escribirWorkbookRels() throws IOException {
        StringBuilder sb = new StringBuilder(256);
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
          .append("<Relationships xmlns=\"").append(NS_PKG_REL).append("\">");
        for (int i = 1; i <= hojas.size(); i++) {
            sb.append("<Relationship Id=\"rId").append(i)
              .append("\" Type=\"").append(NS_REL).append("/worksheet")
              .append("\" Target=\"worksheets/sheet").append(i).append(".xml\"/>");
        }
        // La relacion de estilos va despues de las hojas para no chocar ids.
        sb.append("<Relationship Id=\"rId").append(hojas.size() + 1)
          .append("\" Type=\"").append(NS_REL).append("/styles")
          .append("\" Target=\"styles.xml\"/>")
          .append("</Relationships>");
        entrada("xl/_rels/workbook.xml.rels", sb.toString());
    }

    private void escribirStyles() throws IOException {
        entrada("xl/styles.xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
          + "<styleSheet xmlns=\"" + NS_MAIN + "\">"
          + "<fonts count=\"1\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
          + "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill>"
          + "<fill><patternFill patternType=\"gray125\"/></fill></fills>"
          + "<borders count=\"1\"><border/></borders>"
          + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
          + "<cellXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/></cellXfs>"
          // Sin este "Normal" el paquete no declara estilo por defecto y
          // algunos lectores avisan al abrir el archivo.
          + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
          + "</styleSheet>");
    }

    private void entrada(String nombre, String contenido) throws IOException {
        zip.putNextEntry(new ZipEntry(nombre));
        zip.write(contenido.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    // ---------------------------------------------------------------
    // Utilidades
    // ---------------------------------------------------------------

    /** Indice 0 -> "A", 25 -> "Z", 26 -> "AA". */
    private static String columna(int indice) {
        StringBuilder sb = new StringBuilder(3);
        int n = indice;
        do {
            sb.insert(0, (char) ('A' + (n % 26)));
            n = n / 26 - 1;
        } while (n >= 0);
        return sb.toString();
    }

    /**
     * Excel rechaza el archivo si el nombre de hoja pasa de 31
     * caracteres o contiene : \ / ? * [ ]
     */
    private static String sanearNombreHoja(String nombre) {
        String limpio = nombre.replaceAll("[:\\\\/?*\\[\\]]", "_");
        return limpio.length() > 31 ? limpio.substring(0, 31) : limpio;
    }

    private static void escaparXml(String s, Appendable destino) throws IOException {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&':  destino.append("&amp;");  break;
                case '<':  destino.append("&lt;");   break;
                case '>':  destino.append("&gt;");   break;
                case '"':  destino.append("&quot;"); break;
                case '\'': destino.append("&apos;"); break;
                default:
                    // XML 1.0 no admite caracteres de control salvo
                    // tab, salto de linea y retorno de carro.
                    if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') {
                        destino.append(' ');
                    } else {
                        destino.append(c);
                    }
            }
        }
    }
}
