import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * DSL INTERNO para la tabla "pedidos".
 *
 * Extiende las ideas de DBQuery (method chaining, metaprogramacion con
 * whereAttr, validacion con Regex) a lo que exige la seccion
 * "ACTIVIDADES A DESARROLLAR" del laboratorio:
 *
 *   - varias columnas en el SELECT en vez de una sola;
 *   - varias reglas de Regex a la vez, una por columna, informando
 *     CUAL regla fallo (necesario para el reporte de invalidos);
 *   - reunion opcional con la tabla "persona", para el cruce de
 *     validaciones del punto 4;
 *   - recorrido en streaming, porque la tabla tiene 2.000.000 de filas
 *     y no caben en memoria.
 *
 * Ejemplo:
 *     new PedidoDSL(conn)
 *         .from("pedidos")
 *         .conPersona()
 *         .whereAttr("cantidad", "> 2")
 *         .validate("codigo",   "^[A-Z]{3}-[0-9]{4}-[A-Z]$")
 *         .validate("producto", "^[A-ZAEIOUN][A-Za-z ]*$")
 *         .forEach(r -> System.out.println(r.pedido().codigo()));
 */
public class PedidoDSL {

    private static final Pattern IDENTIFICADOR =
            Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*$");
    private static final Pattern OPERADOR =
            Pattern.compile("^(=|<>|!=|<|<=|>|>=)\\s*-?\\d+$");

    /** Columnas de "pedidos" sobre las que se admite validar o filtrar. */
    private static final List<String> COLUMNAS =
            List.of("id", "usuario_id", "producto", "cantidad", "codigo");

    // -----------------------------------------------------------------
    // Tipos del dominio
    // -----------------------------------------------------------------

    /** Una fila de "pedidos", opcionalmente con los datos de su persona. */
    public record Pedido(int id, int usuarioId, String producto,
                         int cantidad, String codigo,
                         String personaNombre, String personaCorreo,
                         Integer personaEdad) {

        public boolean traePersona() { return personaEdad != null; }
    }

    /** Un pedido junto con la lista de reglas de Regex que incumplio. */
    public record Resultado(Pedido pedido, List<String> errores) {

        public boolean esValido() { return errores.isEmpty(); }

        /** Motivos de rechazo en una sola cadena, para el reporte. */
        public String motivos() {
            return errores.isEmpty() ? "" : String.join("; ", errores);
        }
    }

    /** Receptor de cada fila durante el recorrido en streaming. */
    @FunctionalInterface
    public interface Consumidor {
        void aceptar(Resultado resultado) throws Exception;
    }

    // -----------------------------------------------------------------
    // Estado del constructor fluido
    // -----------------------------------------------------------------

    private final Connection conn;
    private String tabla = "pedidos";
    private boolean conPersona = false;
    private final List<String> condiciones = new ArrayList<>();
    private final Map<String, Pattern> validaciones = new LinkedHashMap<>();
    private int tamanioLote = 10_000;
    private long limite = -1;

    public PedidoDSL(Connection conn) {
        if (conn == null) throw new IllegalArgumentException("Conexion nula");
        this.conn = conn;
    }

    // -----------------------------------------------------------------
    // Interfaz fluida
    // -----------------------------------------------------------------

    public PedidoDSL from(String tabla) {
        exigirIdentificador(tabla, "tabla");
        this.tabla = tabla;
        return this;
    }

    /** Punto 4: trae tambien nombre, correo y edad de la persona duenia. */
    public PedidoDSL conPersona() {
        this.conPersona = true;
        return this;
    }

    /** Metaprogramacion: construye la clausula WHERE en ejecucion. */
    public PedidoDSL whereAttr(String atributo, String operador) {
        exigirColumna(atributo);
        String op = operador == null ? "" : operador.trim();
        if (!OPERADOR.matcher(op).matches()) {
            throw new IllegalArgumentException(
                "Operador no permitido: \"" + operador + "\"");
        }
        condiciones.add("p." + atributo + " " + op);
        return this;
    }

    /** Asocia una regla de Regex a una columna. */
    public PedidoDSL validate(String columna, String patron) {
        exigirColumna(columna);
        validaciones.put(columna, Pattern.compile(patron));
        return this;
    }

    /** Filas que el driver trae por viaje al servidor. */
    public PedidoDSL porLotesDe(int n) {
        if (n <= 0) throw new IllegalArgumentException("El lote debe ser > 0");
        this.tamanioLote = n;
        return this;
    }

    /** Corta el recorrido tras n filas. Util para pruebas rapidas. */
    public PedidoDSL limite(long n) {
        this.limite = n;
        return this;
    }

    // -----------------------------------------------------------------
    // Ejecucion
    // -----------------------------------------------------------------

    public String sqlGenerado() {
        StringBuilder sb = new StringBuilder(256);
        sb.append("SELECT p.id, p.usuario_id, p.producto, p.cantidad, p.codigo");
        if (conPersona) {
            sb.append(", u.nombre, u.correo, u.edad");
        }
        sb.append(" FROM ").append(tabla).append(" p");
        if (conPersona) {
            sb.append(" JOIN persona u ON u.id = p.usuario_id");
        }
        if (!condiciones.isEmpty()) {
            sb.append(" WHERE ").append(String.join(" AND ", condiciones));
        }
        sb.append(" ORDER BY p.id");
        if (limite >= 0) {
            sb.append(" LIMIT ").append(limite);
        }
        return sb.toString();
    }

    /**
     * Recorre el resultado fila por fila aplicando las validaciones.
     *
     * Detalle importante: para que el driver de PostgreSQL use un cursor
     * del lado del servidor y no intente traer los 2.000.000 de filas a
     * memoria de una sola vez, hacen falta DOS cosas a la vez:
     * autoCommit en false y un fetchSize mayor que cero. Si falta
     * cualquiera de las dos, el programa termina en OutOfMemoryError.
     */
    public long forEach(Consumidor consumidor) throws Exception {
        boolean autoCommitPrevio = conn.getAutoCommit();
        conn.setAutoCommit(false);
        long filas = 0;
        try (Statement stmt = conn.createStatement(
                     ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
            stmt.setFetchSize(tamanioLote);
            try (ResultSet rs = stmt.executeQuery(sqlGenerado())) {
                while (rs.next()) {
                    consumidor.aceptar(evaluar(leer(rs)));
                    filas++;
                }
            }
        } finally {
            conn.rollback();                      // cierra el cursor
            conn.setAutoCommit(autoCommitPrevio);
        }
        return filas;
    }

    private Pedido leer(ResultSet rs) throws SQLException {
        int id        = rs.getInt(1);
        int usuarioId = rs.getInt(2);
        String prod   = rs.getString(3);
        int cantidad  = rs.getInt(4);
        String codigo = rs.getString(5);
        if (!conPersona) {
            return new Pedido(id, usuarioId, prod, cantidad, codigo, null, null, null);
        }
        return new Pedido(id, usuarioId, prod, cantidad, codigo,
                          rs.getString(6), rs.getString(7), rs.getInt(8));
    }

    /** Aplica cada Regex registrada y arma la lista de incumplimientos. */
    private Resultado evaluar(Pedido p) {
        List<String> errores = new ArrayList<>(3);
        for (Map.Entry<String, Pattern> regla : validaciones.entrySet()) {
            String valor = switch (regla.getKey()) {
                case "id"         -> Integer.toString(p.id());
                case "usuario_id" -> Integer.toString(p.usuarioId());
                case "producto"   -> p.producto();
                case "cantidad"   -> Integer.toString(p.cantidad());
                case "codigo"     -> p.codigo();
                default           -> null;
            };
            if (valor == null || !regla.getValue().matcher(valor).matches()) {
                errores.add(regla.getKey());
            }
        }
        return new Resultado(p, errores);
    }

    // -----------------------------------------------------------------
    // Utilidades
    // -----------------------------------------------------------------

    private static void exigirIdentificador(String valor, String rol) {
        if (valor == null || !IDENTIFICADOR.matcher(valor).matches()) {
            throw new IllegalArgumentException(
                "Nombre de " + rol + " no valido: \"" + valor + "\"");
        }
    }

    private static void exigirColumna(String columna) {
        if (columna == null || !COLUMNAS.contains(columna)) {
            throw new IllegalArgumentException(
                "Columna desconocida: \"" + columna + "\". Se admiten " + COLUMNAS);
        }
    }
}
