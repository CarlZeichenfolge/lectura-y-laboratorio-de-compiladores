import java.util.regex.Pattern;

/**
 * Expresiones regulares del laboratorio, en un solo lugar.
 * Es el equivalente en Java de las constantes de python/config.py: los
 * patrones son identicos carácter por carácter para que ambas
 * soluciones produzcan exactamente los mismos conteos.
 */
public final class Reglas {

    private Reglas() { }

    /**
     * Punto 5.a / 2.a - codigo de pedido.
     * Tres letras MAYUSCULAS ASCII, guion, cuatro digitos, guion, una
     * letra MAYUSCULA ASCII.
     *   Validos   : LAP-2026-A, MOU-2020-G, SSD-2023-L
     *   Invalidos : MONITOR-XYZ, CABLE_HDMI, SSD_CODE, CAM-2024-M (con tilde)
     */
    public static final String CODIGO = "^[A-Z]{3}-[0-9]{4}-[A-Z]$";

    /**
     * Punto 2.b - nombre de producto: empieza en MAYUSCULA y contiene
     * solo letras y espacios.
     *
     * Las vocales acentuadas se enumeran de forma explicita en lugar de
     * usar \p{Lu} o [[:upper:]] porque cada motor las interpreta
     * distinto: Python re no soporta \p{...} y en PostgreSQL el
     * resultado de [[:alpha:]] depende del LC_CTYPE del servidor. Con la
     * clase explicita, Java, Python y SQL devuelven el mismo conteo.
     *
     *   Validos   : Laptop, SSD, Cable HDMI, Silla Gamer, Microfono
     *   Invalidos : auriculares17, mouse15, silla gamer49
     */
    public static final String PRODUCTO =
            "^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$";

    /** Punto 2.c - cantidad entera positiva. */
    public static final String CANTIDAD = "^[1-9][0-9]*$";

    /** Punto 5.b - correo de persona. */
    public static final String CORREO = "^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$";

    /** Punto 4.a - nombre de persona: mismo criterio que el de producto. */
    public static final String NOMBRE = PRODUCTO;

    public static final int EDAD_MINIMA = 18;

    // Versiones ya compiladas, para el cruce de validaciones del punto 4.
    public static final Pattern P_NOMBRE = Pattern.compile(NOMBRE);
    public static final Pattern P_CORREO = Pattern.compile(CORREO);

    /** Punto 4.a - una persona es valida si sus tres campos lo son. */
    public static boolean personaValida(String nombre, String correo, Integer edad) {
        return nombre != null && P_NOMBRE.matcher(nombre).matches()
            && correo != null && P_CORREO.matcher(correo).matches()
            && edad   != null && edad >= EDAD_MINIMA;
    }

    /** Detalla que campos de la persona estan mal. Para el reporte 4.b. */
    public static String motivoPersona(String nombre, String correo, Integer edad) {
        StringBuilder sb = new StringBuilder();
        if (nombre == null || !P_NOMBRE.matcher(nombre).matches()) sb.append("nombre; ");
        if (correo == null || !P_CORREO.matcher(correo).matches()) sb.append("correo; ");
        if (edad == null || edad < EDAD_MINIMA)                    sb.append("edad; ");
        if (sb.length() >= 2) sb.setLength(sb.length() - 2);
        return sb.toString();
    }
}
