"""
A4-LABORATORIO : DSL y Regex en Validacion de Dataset

PASO 2 de 3 - Carga masiva de los CSV a PostgreSQL.

Requisito previo: haber ejecutado sql/01_esquema.sql.
Paso siguiente  : ejecutar sql/02_restricciones_indices.sql.

POR QUE ESTE SCRIPT Y NO UN "INSERT" POR FILA
---------------------------------------------
El dataset tiene 2.000.000 de pedidos. Insertarlos uno por uno tarda
horas. La orden COPY de PostgreSQL los carga en menos de un minuto.

POR QUE "COPY ... FROM STDIN" Y NO "COPY ... FROM '<ruta>'"
----------------------------------------------------------
"COPY FROM '<ruta>'" lo ejecuta el SERVIDOR, que debe poder leer el
archivo con la cuenta de servicio de PostgreSQL. En Windows esa cuenta
normalmente no tiene acceso a la carpeta Descargas del usuario, y la
orden falla con "could not open file ... Permission denied".
"COPY FROM STDIN" (copy_expert) envia el archivo desde el CLIENTE por
el mismo socket de la conexion: funciona siempre y no exige permisos
especiales ni ser superusuario.

Uso:
    python cargar_datos.py
"""

import sys
import time

import psycopg2

import config


def copiar(cur, tabla, ruta_csv, etiqueta):
    """Carga un CSV con encabezado dentro de 'tabla' usando COPY FROM STDIN."""
    if not ruta_csv.exists():
        raise FileNotFoundError(f"No se encontro {ruta_csv}")

    tam_mb = ruta_csv.stat().st_size / (1024 * 1024)
    print(f"  [{etiqueta}] {ruta_csv.name}  ({tam_mb:,.1f} MB)")

    inicio = time.perf_counter()
    cur.execute(f"TRUNCATE TABLE {tabla} CASCADE;")
    with open(ruta_csv, "rb") as f:
        cur.copy_expert(
            f"COPY {tabla} FROM STDIN WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')",
            f,
        )
    cur.execute(f"SELECT COUNT(*) FROM {tabla};")
    filas = cur.fetchone()[0]
    print(f"  [{etiqueta}] {filas:,} filas en {time.perf_counter() - inicio:,.1f} s")
    return filas


def main():
    print("=" * 70)
    print(" CARGA DE DATOS A PostgreSQL")
    print("=" * 70)
    print(f"  destino: {config.USER}@{config.HOST}:{config.PORT}/{config.DATABASE}")
    print()

    try:
        conn = psycopg2.connect(**config.DSN)
    except psycopg2.OperationalError as e:
        print("ERROR: no se pudo conectar a PostgreSQL.")
        print(f"       {str(e).strip()}")
        print()
        print("  Revise que el servicio este arriba y que las credenciales de")
        print("  config.py (o las variables PGUSER / PGPASSWORD) sean correctas.")
        sys.exit(1)

    conn.set_client_encoding("UTF8")

    try:
        with conn, conn.cursor() as cur:
            # El orden importa: 'persona' primero, porque despues se creara
            # la llave foranea pedidos.usuario_id -> persona.id
            copiar(cur, "persona", config.CSV_PERSONA, "1/2 persona")
            copiar(cur, "pedidos", config.CSV_PEDIDOS, "2/2 pedidos")

            # Comprobacion de integridad ANTES de aplicar la llave foranea,
            # para dar un mensaje claro si algo no cuadra.
            cur.execute("""
                SELECT COUNT(*)
                FROM   pedidos p
                LEFT   JOIN persona u ON u.id = p.usuario_id
                WHERE  u.id IS NULL
            """)
            huerfanos = cur.fetchone()[0]

        print()
        if huerfanos == 0:
            print("  Integridad referencial OK: 0 pedidos huerfanos.")
            print("  Ya puede ejecutar sql/02_restricciones_indices.sql")
        else:
            print(f"  ATENCION: {huerfanos:,} pedidos apuntan a usuarios inexistentes.")
            print("  Vuelva a generar persona_dataset.csv con GenerarPersonas.java")
            print("  antes de aplicar la llave foranea.")
    finally:
        conn.close()

    print("=" * 70)


if __name__ == "__main__":
    main()
