"""
A4-LABORATORIO : DSL y Regex en Validacion de Dataset
Configuracion compartida por todos los scripts de Python.

Los parametros de conexion se leen de variables de entorno y, si no
existen, caen a los valores por defecto de una instalacion tipica de
PostgreSQL con pgAdmin 4.

    >>> $env:PGPASSWORD = "mi_clave"      # PowerShell, solo esta sesion
    >>> python cargar_datos.py

Si prefiere no usar variables de entorno, edite PASSWORD mas abajo.
"""

import os
import re
from pathlib import Path

# ---------------------------------------------------------------------
# Rutas del proyecto
# ---------------------------------------------------------------------
RAIZ_PY   = Path(__file__).resolve().parent          # taller/python
TALLER    = RAIZ_PY.parent                           # taller
PROYECTO  = TALLER.parent                            # carpeta de trabajo

DIR_ORIGEN  = PROYECTO / "LABCLASES"                 # archivos del profesor
DIR_DATA    = TALLER / "data"                        # datos generados
DIR_SALIDAS = TALLER / "salidas"                     # reportes Excel / TXT

CSV_PERSONA = DIR_DATA / "persona_dataset.csv"
CSV_PEDIDOS = DIR_ORIGEN / "pedidos_dataset.csv"
CSV_BASE    = DIR_ORIGEN / "dataset.csv"

DIR_SALIDAS.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------
# Conexion a PostgreSQL
# ---------------------------------------------------------------------
def _leer_credenciales(ruta: Path) -> dict:
    """Lee un archivo simple de pares CLAVE=VALOR, ignorando comentarios."""
    valores = {}
    if not ruta.exists():
        return valores
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#") or "=" not in linea:
            continue
        clave, _, valor = linea.partition("=")
        valores[clave.strip()] = valor.strip()
    return valores


_ARCHIVO = _leer_credenciales(TALLER / "credenciales.env")


def _cfg(clave: str, por_defecto: str) -> str:
    """Prioridad: variable de entorno > credenciales.env > valor por defecto."""
    return os.environ.get(clave) or _ARCHIVO.get(clave) or por_defecto


HOST     = _cfg("PGHOST",     "localhost")
PORT     = int(_cfg("PGPORT", "5432"))
DATABASE = _cfg("PGDATABASE", "ubosquebd")
USER     = _cfg("PGUSER",     "postgres")
PASSWORD = _cfg("PGPASSWORD", "postgres")

DSN = dict(host=HOST, port=PORT, dbname=DATABASE, user=USER, password=PASSWORD)


# ---------------------------------------------------------------------
# Expresiones regulares del laboratorio
# ---------------------------------------------------------------------

# Punto 5.a / 2.a : codigo de pedido. Tres letras MAYUSCULAS ASCII, guion,
# cuatro digitos, guion, una letra MAYUSCULA ASCII.
#   Validos   : LAP-2026-A, MOU-2020-G, SSD-2023-L
#   Invalidos : MONITOR-XYZ, CABLE_HDMI, SSD_CODE, CAM-2024-M (con tilde)
RE_CODIGO = re.compile(r"^[A-Z]{3}-[0-9]{4}-[A-Z]$")

# Punto 2.b : nombre de producto. Empieza en MAYUSCULA y contiene solo
# letras y espacios.
#
# Se enumeran explicitamente las vocales acentuadas en vez de usar
# \p{Lu} / [[:upper:]] porque cada motor las interpreta distinto:
# Python re no soporta \p{...}, y en PostgreSQL el resultado de
# [[:alpha:]] depende del LC_CTYPE del servidor. Con la clase explicita
# los tres lenguajes (Python, Java y SQL) devuelven EXACTAMENTE el mismo
# conteo, que es lo que permite contrastar los resultados en el informe.
#
#   Validos   : Laptop, Cable HDMI, SSD, Silla Gamer, Microfono, Camara Web
#   Invalidos : auriculares17, mouse15, silla gamer49  (minuscula + digitos)
RE_PRODUCTO = re.compile(r"^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$")

# Punto 2.c : cantidad entera positiva.
RE_CANTIDAD = re.compile(r"^[1-9][0-9]*$")

# Punto 5.b : correo de persona.
RE_CORREO = re.compile(r"^[\w\.-]+@[\w\.-]+\.\w+$")

# Punto 4.a : nombre de persona (mismo criterio que el de producto).
RE_NOMBRE = RE_PRODUCTO

EDAD_MINIMA = 18


def producto_valido(texto: str) -> bool:
    """Empieza en mayuscula y solo contiene letras y espacios."""
    return texto is not None and RE_PRODUCTO.fullmatch(texto) is not None


def cantidad_valida(valor) -> bool:
    """Entero positivo. Acepta int o la cadena leida del CSV."""
    if isinstance(valor, int):
        return valor > 0
    return RE_CANTIDAD.fullmatch(str(valor).strip()) is not None


def codigo_valido(texto: str) -> bool:
    """Patron ^[A-Z]{3}-[0-9]{4}-[A-Z]$ (punto 5.a)."""
    return texto is not None and RE_CODIGO.fullmatch(texto) is not None


def correo_valido(texto: str) -> bool:
    """Patron ^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$ (punto 5.b)."""
    return texto is not None and RE_CORREO.fullmatch(texto) is not None


def persona_valida(nombre: str, correo: str, edad) -> bool:
    """Punto 4.a: una persona es valida si sus tres campos lo son."""
    return (producto_valido(nombre)          # mismo criterio de nombre
            and correo_valido(correo)
            and isinstance(edad, int) and edad >= EDAD_MINIMA)


def motivo_persona(nombre: str, correo: str, edad) -> str:
    """Detalla que campos de la persona estan mal. Para el reporte 4.b."""
    fallos = []
    if not producto_valido(nombre):
        fallos.append("nombre")
    if not correo_valido(correo):
        fallos.append("correo")
    if not (isinstance(edad, int) and edad >= EDAD_MINIMA):
        fallos.append("edad")
    return "; ".join(fallos)
