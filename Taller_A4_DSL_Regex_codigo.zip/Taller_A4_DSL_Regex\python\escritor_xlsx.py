"""
Escritor de archivos .xlsx en streaming, con particionado automatico de
hojas. Equivalente en Python de MiniXlsx.java.

POR QUE HACE FALTA
------------------
Una hoja de Excel admite como maximo 1.048.576 filas, encabezado
incluido. El reporte de pedidos validos supera esa cifra, asi que al
llenarse la hoja en curso se abre otra ("Validos_2", "Validos_3", ...)
y se le repite el encabezado.

Ademas se usa el modo write_only de openpyxl: las filas no se guardan
como objetos Cell en memoria, sino que se van serializando a disco. Sin
eso, un millon de filas agota la RAM.
"""

from openpyxl import Workbook

# Maximo de filas por hoja en Excel, encabezado incluido.
MAX_FILAS_HOJA = 1_048_576

# Caracteres que Excel prohibe en el nombre de una hoja.
_PROHIBIDOS = str.maketrans({c: "_" for c in ":\\/?*[]"})


class EscritorXlsx:
    """
    Uso:
        with EscritorXlsx(ruta, "Validos", ["ID", "Producto"]) as x:
            x.fila(1, "Laptop")
    """

    def __init__(self, ruta, nombre_hoja, encabezados):
        self.ruta = ruta
        self.nombre_base = self._sanear(nombre_hoja)
        self.encabezados = list(encabezados)
        self.wb = Workbook(write_only=True)
        self.hojas = 0
        self.filas_hoja = 0        # incluye el encabezado
        self.filas_escritas = 0    # solo filas de datos
        self.ws = None
        self._abrir_hoja()

    # -- contexto ----------------------------------------------------
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.cerrar()
        return False

    # -- API ---------------------------------------------------------
    def fila(self, *valores):
        if self.filas_hoja >= MAX_FILAS_HOJA:
            self._abrir_hoja()
        self.ws.append(list(valores))
        self.filas_hoja += 1
        self.filas_escritas += 1

    def cerrar(self):
        if self.wb is not None:
            self.wb.save(self.ruta)
            self.wb.close()
            self.wb = None

    # -- interno -----------------------------------------------------
    def _abrir_hoja(self):
        self.hojas += 1
        nombre = (self.nombre_base if self.hojas == 1
                  else self._sanear(f"{self.nombre_base}_{self.hojas}"))
        self.ws = self.wb.create_sheet(nombre)
        self.filas_hoja = 0
        if self.encabezados:
            self.ws.append(self.encabezados)
            self.filas_hoja += 1

    @staticmethod
    def _sanear(nombre):
        """Excel rechaza nombres de mas de 31 caracteres o con : \\ / ? * [ ]"""
        return nombre.translate(_PROHIBIDOS)[:31]
