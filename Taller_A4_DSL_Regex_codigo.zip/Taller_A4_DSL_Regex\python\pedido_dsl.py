"""
DSL INTERNO para la tabla "pedidos" - version Python.

Equivalente de PedidoDSL.java. Extiende las ideas del ejemplo base
(method chaining, metaprogramacion con where_attr, validacion con Regex)
a lo que exige la seccion "ACTIVIDADES A DESARROLLAR":

  - varias columnas en el SELECT en vez de una sola;
  - varias reglas de Regex a la vez, una por columna, informando CUAL
    regla fallo (necesario para el reporte de invalidos);
  - reunion opcional con la tabla "persona" para el punto 4;
  - recorrido en streaming, porque la tabla tiene 2.000.000 de filas.
"""

import re
from dataclasses import dataclass, field
from typing import Callable, Optional

RE_IDENTIFICADOR = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
RE_OPERADOR = re.compile(r"^(=|<>|!=|<|<=|>|>=)\s*-?\d+$")

COLUMNAS = ("id", "usuario_id", "producto", "cantidad", "codigo")


@dataclass(slots=True)
class Pedido:
    """Una fila de "pedidos", opcionalmente con los datos de su persona."""
    id: int
    usuario_id: int
    producto: str
    cantidad: int
    codigo: str
    persona_nombre: Optional[str] = None
    persona_correo: Optional[str] = None
    persona_edad: Optional[int] = None

    @property
    def trae_persona(self) -> bool:
        return self.persona_edad is not None


@dataclass(slots=True)
class Resultado:
    """Un pedido junto con la lista de reglas de Regex que incumplio."""
    pedido: Pedido
    errores: list

    @property
    def es_valido(self) -> bool:
        return not self.errores

    @property
    def motivos(self) -> str:
        return "; ".join(self.errores)


class PedidoDSL:
    """
    Constructor fluido de consultas sobre "pedidos".

    Ejemplo:
        (PedidoDSL(conn)
            .from_("pedidos")
            .con_persona()
            .where_attr("cantidad", "> 2")
            .validate("codigo", RE_CODIGO)
            .for_each(lambda r: print(r.pedido.codigo)))
    """

    def __init__(self, conn):
        if conn is None:
            raise ValueError("La conexion no puede ser nula")
        self.conn = conn
        self.tabla = "pedidos"
        self._con_persona = False
        self.condiciones = []
        self.validaciones = {}       # columna -> patron compilado
        self.tamanio_lote = 20_000
        self.limite = None

    # -- interfaz fluida --------------------------------------------
    def from_(self, tabla):
        self._exigir_identificador(tabla, "tabla")
        self.tabla = tabla
        return self

    def con_persona(self):
        """Punto 4: trae tambien nombre, correo y edad de la persona."""
        self._con_persona = True
        return self

    def where_attr(self, atributo, operador):
        """Metaprogramacion: construye la clausula WHERE en ejecucion."""
        self._exigir_columna(atributo)
        op = (operador or "").strip()
        if not RE_OPERADOR.fullmatch(op):
            raise ValueError(f'Operador no permitido: "{operador}"')
        self.condiciones.append(f"p.{atributo} {op}")
        return self

    def validate(self, columna, patron):
        """Asocia una regla de Regex a una columna."""
        self._exigir_columna(columna)
        self.validaciones[columna] = (
            patron if hasattr(patron, "fullmatch") else re.compile(patron)
        )
        return self

    def por_lotes_de(self, n):
        if n <= 0:
            raise ValueError("El lote debe ser > 0")
        self.tamanio_lote = n
        return self

    def con_limite(self, n):
        """Corta el recorrido tras n filas. Util para pruebas rapidas."""
        self.limite = n
        return self

    # -- ejecucion ---------------------------------------------------
    def sql_generado(self):
        campos = "p.id, p.usuario_id, p.producto, p.cantidad, p.codigo"
        if self._con_persona:
            campos += ", u.nombre, u.correo, u.edad"
        sql = f"SELECT {campos} FROM {self.tabla} p"
        if self._con_persona:
            sql += " JOIN persona u ON u.id = p.usuario_id"
        if self.condiciones:
            sql += " WHERE " + " AND ".join(self.condiciones)
        sql += " ORDER BY p.id"
        if self.limite is not None:
            sql += f" LIMIT {int(self.limite)}"
        return sql

    def for_each(self, consumidor: Callable[[Resultado], None]) -> int:
        """
        Recorre el resultado fila por fila aplicando las validaciones.

        Se usa un cursor CON NOMBRE. En psycopg2 eso crea un cursor del
        lado del SERVIDOR, que devuelve los datos por lotes de
        "itersize" filas. Con un cursor normal (sin nombre) psycopg2
        trae las 2.000.000 de filas a memoria de una sola vez y el
        proceso muere por falta de RAM.
        """
        sql = self.sql_generado()
        nombre = f"dsl_pedidos_{id(self)}"
        filas = 0
        with self.conn.cursor(name=nombre) as cur:
            cur.itersize = self.tamanio_lote
            cur.execute(sql)
            for fila in cur:
                consumidor(self._evaluar(self._leer(fila)))
                filas += 1
        self.conn.rollback()      # cierra el cursor del servidor
        return filas

    # -- interno -----------------------------------------------------
    def _leer(self, fila) -> Pedido:
        if not self._con_persona:
            return Pedido(fila[0], fila[1], fila[2], fila[3], fila[4])
        return Pedido(fila[0], fila[1], fila[2], fila[3], fila[4],
                      fila[5], fila[6], fila[7])

    def _evaluar(self, p: Pedido) -> Resultado:
        """Aplica cada Regex registrada y arma la lista de incumplimientos."""
        valores = {
            "id": p.id,
            "usuario_id": p.usuario_id,
            "producto": p.producto,
            "cantidad": p.cantidad,
            "codigo": p.codigo,
        }
        errores = []
        for columna, patron in self.validaciones.items():
            valor = valores[columna]
            if valor is None or not patron.fullmatch(str(valor)):
                errores.append(columna)
        return Resultado(p, errores)

    @staticmethod
    def _exigir_identificador(valor, rol):
        if not valor or not RE_IDENTIFICADOR.fullmatch(valor):
            raise ValueError(f'Nombre de {rol} no valido: "{valor}"')

    @staticmethod
    def _exigir_columna(columna):
        if columna not in COLUMNAS:
            raise ValueError(
                f'Columna desconocida: "{columna}". Se admiten {list(COLUMNAS)}'
            )
