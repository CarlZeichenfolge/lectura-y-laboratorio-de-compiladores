"""
PARTE A del laboratorio - ejemplo base desplegado sobre PostgreSQL.

Version corregida de "SolutionPython.py". Reproduce la misma salida que
AplMainDSL.java: los correos que cumplen ^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$
entre las personas mayores de 18 anios.

DEFECTOS DEL SCRIPT ORIGINAL Y SU CORRECCION
--------------------------------------------
1. Usaba la variable "conn" sin haberla definido ni importado ningun
   driver: el script terminaba en NameError antes de consultar nada.
   -> Ahora se abre la conexion explicitamente con psycopg2.
2. Consultaba la tabla "usuarios"; el esquema de este laboratorio la
   llama "persona".
3. Usaba re.match(), que solo ancla al inicio de la cadena. Con un
   patron que ya trae ^...$ el efecto es casi el mismo, pero "$" en
   Python tambien admite un salto de linea final, asi que
   "ana@example.com\\n" pasaria como valido. -> Se usa fullmatch().
4. Interpolaba tabla y campo en el SQL sin ninguna comprobacion.
   -> Se validan como identificadores con Regex antes de concatenar.
5. Nunca cerraba cursor ni conexion. -> Context managers.
6. execute() no contemplaba valores NULL. -> Se descartan.
7. whereAttr() dejaba pasar cualquier cadena como operador y una
   segunda llamada pisaba la primera. -> Se valida con Regex y las
   condiciones se acumulan con AND.

Ejecucion:
    python solucion_ejemplo.py
"""

import re
import sys

import psycopg2

import config

# Un identificador SQL legitimo: letras, digitos y guion bajo, sin
# empezar por digito.
RE_IDENTIFICADOR = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Un operador de comparacion seguido de un literal numerico: "> 18".
# Impide que por where_attr entre "0 OR 1=1; DROP TABLE persona".
RE_OPERADOR = re.compile(r"^(=|<>|!=|<|<=|>|>=)\s*-?\d+$")


class DBQuery:
    """
    DSL interno para consultar una tabla y validar el resultado con Regex.

    Tecnicas que implementa:
      - Method chaining: cada metodo devuelve "self".
      - Metaprogramacion: where_attr() arma la clausula WHERE en tiempo
        de ejecucion a partir de un nombre de atributo y un operador.
      - Procesamiento de colecciones: execute() filtra con el patron.
    """

    def __init__(self, conn):
        if conn is None:
            raise ValueError("La conexion no puede ser nula")
        self.conn = conn
        self.table = None
        self.field = None
        self.conditions = []
        self.regex = None

    # -- interfaz fluida --------------------------------------------
    def from_(self, table):
        self._exigir_identificador(table, "tabla")
        self.table = table
        return self

    def select(self, field):
        self._exigir_identificador(field, "campo")
        self.field = field
        return self

    def where_attr(self, attr, operator):
        """Metaprogramacion: genera la condicion en ejecucion."""
        self._exigir_identificador(attr, "atributo")
        op = (operator or "").strip()
        if not RE_OPERADOR.fullmatch(op):
            raise ValueError(
                f'Operador no permitido: "{operator}". '
                'Se espera algo como "> 18" o ">= 3".'
            )
        self.conditions.append(f"{attr} {op}")
        return self

    def validate_with(self, regex_pattern):
        self.regex = re.compile(regex_pattern)
        return self

    # -- ejecucion ---------------------------------------------------
    def sql_generado(self):
        """Devuelve el SQL que el DSL construyo. Util para evidencias."""
        if self.table is None or self.field is None:
            raise RuntimeError("Falta invocar from_() y/o select()")
        where = f" WHERE {' AND '.join(self.conditions)}" if self.conditions else ""
        return f"SELECT {self.field} FROM {self.table}{where} ORDER BY {self.field}"

    def execute(self):
        sql = self.sql_generado()
        with self.conn.cursor() as cur:
            cur.execute(sql)
            filas = cur.fetchall()
        return [
            r[0] for r in filas
            if r[0] is not None and (self.regex is None or self.regex.fullmatch(r[0]))
        ]

    @staticmethod
    def _exigir_identificador(valor, rol):
        if not valor or not RE_IDENTIFICADOR.fullmatch(valor):
            raise ValueError(f'Nombre de {rol} no valido: "{valor}"')


def main():
    print("======================================================")
    print(" PARTE A - Ejemplo base del DSL")
    print(f" Conexion: {config.USER}@{config.HOST}:{config.PORT}/{config.DATABASE}")
    print("======================================================")

    try:
        conn = psycopg2.connect(**config.DSN)
    except psycopg2.OperationalError as e:
        print("ERROR: no se pudo conectar a PostgreSQL.")
        print(f"       {str(e).strip()}")
        sys.exit(1)

    try:
        conn.set_client_encoding("UTF8")

        # "id <= 20" acota la consulta a las 20 personas de dataset.csv,
        # que son las del ejemplo del enunciado. La tabla contiene ademas
        # mas de un millon de personas generadas para dar soporte a la
        # llave foranea de los 2.000.000 de pedidos.
        consulta = (DBQuery(conn)
                    .from_("persona")
                    .select("correo")
                    .where_attr("edad", "> 18")
                    .where_attr("id", "<= 20")
                    .validate_with(r"^[\w\.-]+@[\w\.-]+\.\w+$"))

        print("SQL generado por el DSL:")
        print("  " + consulta.sql_generado())
        print()

        validados = consulta.execute()
        for correo in validados:
            print(f"Correo valido: {correo}")

        print()
        print(f"Total de correos validos: {len(validados)}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
