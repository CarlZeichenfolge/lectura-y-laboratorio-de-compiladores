"""
PARTES B y C del laboratorio - solucion en Python sobre la tabla "pedidos".

Resuelve, en este orden, los puntos de "ACTIVIDADES A DESARROLLAR":

  2.a  validacion de codigos con Regex      ^[A-Z]{3}-[0-9]{4}-[A-Z]$
  2.b  validacion de nombres de producto    mayuscula inicial, letras y espacios
  2.c  validacion de cantidades             entero positivo
  2.d  filtro dinamico por el DSL           pedidos con mas de 2 unidades
  2.e  reportes en Excel                    validos e invalidos
  2.f  promedio de cantidad de los validos
  2.g  conteo de validos e invalidos
  2.h  producto mas pedido entre los validos
  4.a  cruce: solo personas correctas pueden tener pedidos validos
  4.b  reporte de pedidos descartados por persona invalida

Produce exactamente los mismos numeros que AplPedidos.java.

Ejecucion:
    python solucion_pedidos.py
"""

import sys
import time
from collections import Counter

import psycopg2

import config
from escritor_xlsx import EscritorXlsx
from pedido_dsl import PedidoDSL

DIR_SALIDA = config.DIR_SALIDAS / "python"


class Metricas:
    """Acumulador de estadisticas del recorrido."""

    def __init__(self):
        self.total = 0
        self.validos = 0
        self.invalidos = 0
        self.suma_cantidades = 0

        # Punto 2.g - desglose por regla incumplida
        self.fallo_codigo = 0
        self.fallo_producto = 0
        self.fallo_cantidad = 0

        # Punto 4 - cruce con persona
        self.validos_con_persona_ok = 0
        self.descartados_por_persona = 0
        self.persona_fallo_nombre = 0
        self.persona_fallo_correo = 0
        self.persona_fallo_edad = 0

        # Punto 2.h - histograma de productos entre los validos
        self.pedidos_por_producto = Counter()
        self.unidades_por_producto = Counter()


def titulo(texto):
    print()
    print("=" * 70)
    print(" " + texto)
    print("=" * 70)


def pct(parte, total):
    return 0.0 if total == 0 else 100.0 * parte / total


# =====================================================================
#  Recorrido principal: una sola pasada sobre los 2.000.000 de filas
# =====================================================================
def recorrido_principal(conn) -> Metricas:
    titulo("Recorrido principal (puntos 2.a, 2.b, 2.c, 2.e, 4.a, 4.b)")

    m = Metricas()

    dsl = (PedidoDSL(conn)
           .from_("pedidos")
           .con_persona()                                  # punto 4
           .validate("codigo", config.RE_CODIGO)           # punto 2.a
           .validate("producto", config.RE_PRODUCTO)       # punto 2.b
           .validate("cantidad", config.RE_CANTIDAD)       # punto 2.c
           .por_lotes_de(20_000))

    print("  SQL generado por el DSL:")
    print("    " + dsl.sql_generado())
    print()

    cab = ["ID", "Usuario_ID", "Producto", "Cantidad", "Codigo"]
    cab_mal = cab + ["Motivo_Rechazo"]
    cab_desc = cab + ["Nombre_Persona", "Correo_Persona", "Edad_Persona",
                      "Motivo_Persona"]

    with EscritorXlsx(DIR_SALIDA / "pedidos_validos.xlsx", "Validos", cab) as ok_xls, \
         EscritorXlsx(DIR_SALIDA / "pedidos_invalidos.xlsx", "Invalidos", cab_mal) as mal_xls, \
         EscritorXlsx(DIR_SALIDA / "pedidos_descartados_usuario_invalido.xlsx",
                      "Descartados", cab_desc) as desc_xls:

        def procesar(r):
            p = r.pedido
            m.total += 1

            if r.es_valido:
                # ---- punto 2.e: reporte de validos --------------------
                m.validos += 1
                m.suma_cantidades += p.cantidad
                m.pedidos_por_producto[p.producto] += 1          # punto 2.h
                m.unidades_por_producto[p.producto] += p.cantidad
                ok_xls.fila(p.id, p.usuario_id, p.producto, p.cantidad, p.codigo)

                # ---- punto 4: cruce con la persona -------------------
                if config.persona_valida(p.persona_nombre, p.persona_correo,
                                         p.persona_edad):
                    m.validos_con_persona_ok += 1
                else:
                    m.descartados_por_persona += 1
                    motivo = config.motivo_persona(p.persona_nombre,
                                                   p.persona_correo, p.persona_edad)
                    if "nombre" in motivo:
                        m.persona_fallo_nombre += 1
                    if "correo" in motivo:
                        m.persona_fallo_correo += 1
                    if "edad" in motivo:
                        m.persona_fallo_edad += 1
                    desc_xls.fila(p.id, p.usuario_id, p.producto, p.cantidad,
                                  p.codigo, p.persona_nombre, p.persona_correo,
                                  p.persona_edad, motivo)
            else:
                # ---- punto 2.e: reporte de invalidos ------------------
                m.invalidos += 1
                if "codigo" in r.errores:
                    m.fallo_codigo += 1
                if "producto" in r.errores:
                    m.fallo_producto += 1
                if "cantidad" in r.errores:
                    m.fallo_cantidad += 1
                mal_xls.fila(p.id, p.usuario_id, p.producto, p.cantidad,
                             p.codigo, r.motivos)

            if m.total % 250_000 == 0:
                print(f"    procesados {m.total:,} ...")

        dsl.for_each(procesar)

        print()
        print(f"  pedidos_validos.xlsx                        -> "
              f"{ok_xls.filas_escritas:,} filas en {ok_xls.hojas} hoja(s)")
        print(f"  pedidos_invalidos.xlsx                      -> "
              f"{mal_xls.filas_escritas:,} filas en {mal_xls.hojas} hoja(s)")
        print(f"  pedidos_descartados_usuario_invalido.xlsx   -> "
              f"{desc_xls.filas_escritas:,} filas en {desc_xls.hojas} hoja(s)")

    return m


# =====================================================================
#  Punto 2.d - filtro dinamico con el DSL
# =====================================================================
def filtro_mas_de_dos_unidades(conn):
    titulo("Punto 2.d - filtro dinamico: pedidos con mas de 2 unidades")

    # La condicion NO esta escrita en el SQL: la genera where_attr() en
    # tiempo de ejecucion a partir del nombre del atributo y del
    # operador. Eso es la metaprogramacion que pide el enunciado.
    dsl = (PedidoDSL(conn)
           .from_("pedidos")
           .where_attr("cantidad", "> 2")
           .validate("codigo", config.RE_CODIGO)
           .validate("producto", config.RE_PRODUCTO)
           .validate("cantidad", config.RE_CANTIDAD)
           .por_lotes_de(20_000))

    print("  SQL generado por el DSL:")
    print("    " + dsl.sql_generado())
    print()

    cont = {"leidos": 0, "validos": 0}
    muestra = []

    with EscritorXlsx(DIR_SALIDA / "pedidos_mas_de_2_unidades.xlsx",
                      "MasDe2Unidades",
                      ["ID", "Usuario_ID", "Producto", "Cantidad", "Codigo"]) as xls:

        def procesar(r):
            cont["leidos"] += 1
            if not r.es_valido:
                return
            cont["validos"] += 1
            p = r.pedido
            xls.fila(p.id, p.usuario_id, p.producto, p.cantidad, p.codigo)
            if len(muestra) < 10:
                muestra.append(f"    {p.id:<8} {p.producto:<14} {p.cantidad:2}  {p.codigo}")

        dsl.for_each(procesar)

        print(f"  pedidos con cantidad > 2            : {cont['leidos']:,}")
        print(f"  de esos, ademas validos por Regex   : {cont['validos']:,}")
        print(f"  pedidos_mas_de_2_unidades.xlsx      -> "
              f"{xls.filas_escritas:,} filas en {xls.hojas} hoja(s)")

    print()
    print("  Primeros 10 del listado:")
    print(f"    {'ID':<8} {'PRODUCTO':<14} {'CT':>2}  CODIGO")
    for linea in muestra:
        print(linea)


# =====================================================================
#  Informe por consola (puntos 2.f, 2.g, 2.h y 4)
# =====================================================================
def informe(m: Metricas):
    titulo("Puntos 2.f, 2.g, 2.h - estadisticas")

    print(f"  Total de pedidos procesados : {m.total:,}")
    print(f"  Pedidos VALIDOS             : {m.validos:,}  ({pct(m.validos, m.total):.2f} %)")
    print(f"  Pedidos INVALIDOS           : {m.invalidos:,}  ({pct(m.invalidos, m.total):.2f} %)")
    print()
    print("  Desglose de los invalidos (un pedido puede fallar varias reglas):")
    print(f"    codigo no cumple el patron   : {m.fallo_codigo:,}")
    print(f"    producto mal escrito         : {m.fallo_producto:,}")
    print(f"    cantidad no positiva         : {m.fallo_cantidad:,}")
    print()

    promedio = 0 if m.validos == 0 else m.suma_cantidades / m.validos
    print(f"  Promedio de cantidad por pedido valido : {promedio:.4f}")
    print(f"  (suma de cantidades = {m.suma_cantidades:,}  /  "
          f"pedidos validos = {m.validos:,})")
    print()

    print("  Punto 2.h - productos mas pedidos entre los validos:")
    print(f"    {'PRODUCTO':<14} {'PEDIDOS':>12} {'UNIDADES':>12}")
    for producto, veces in m.pedidos_por_producto.most_common(10):
        print(f"    {producto:<14} {veces:>12,} {m.unidades_por_producto[producto]:>12,}")

    if m.pedidos_por_producto:
        top, veces = m.pedidos_por_producto.most_common(1)[0]
        print()
        print(f"  >> PRODUCTO MAS PEDIDO: {top}  "
              f"({veces:,} pedidos, {m.unidades_por_producto[top]:,} unidades)")

    titulo("Punto 4 - cruce de validaciones pedidos <-> persona")
    print(f"  Pedidos validos por Regex                     : {m.validos:,}")
    print(f"  ... cuya persona TAMBIEN es valida (4.a)      : "
          f"{m.validos_con_persona_ok:,}  ({pct(m.validos_con_persona_ok, m.validos):.2f} %)")
    print(f"  ... DESCARTADOS por persona invalida (4.b)    : "
          f"{m.descartados_por_persona:,}  ({pct(m.descartados_por_persona, m.validos):.2f} %)")
    print()
    print("  Motivo del descarte (la persona puede fallar en varios campos):")
    print(f"    nombre no empieza en mayuscula : {m.persona_fallo_nombre:,}")
    print(f"    correo no cumple el patron     : {m.persona_fallo_correo:,}")
    print(f"    edad menor de {config.EDAD_MINIMA}                : {m.persona_fallo_edad:,}")


# =====================================================================
#  Resumen en archivo de texto
# =====================================================================
def escribir_resumen(m: Metricas):
    promedio = 0 if m.validos == 0 else m.suma_cantidades / m.validos
    lineas = [
        "RESUMEN DE VALIDACION - SOLUCION EN PYTHON",
        "==========================================",
        "",
        f"Regex de codigo   : {config.RE_CODIGO.pattern}",
        f"Regex de producto : {config.RE_PRODUCTO.pattern}",
        f"Regex de cantidad : {config.RE_CANTIDAD.pattern}",
        f"Regex de correo   : {config.RE_CORREO.pattern}",
        "",
        f"Total de pedidos    : {m.total:,}",
        f"Pedidos validos     : {m.validos:,} ({pct(m.validos, m.total):.2f} %)",
        f"Pedidos invalidos   : {m.invalidos:,} ({pct(m.invalidos, m.total):.2f} %)",
        f"  fallo codigo      : {m.fallo_codigo:,}",
        f"  fallo producto    : {m.fallo_producto:,}",
        f"  fallo cantidad    : {m.fallo_cantidad:,}",
        f"Promedio cantidad   : {promedio:.4f}",
    ]
    if m.pedidos_por_producto:
        top, veces = m.pedidos_por_producto.most_common(1)[0]
        lineas.append(f"Producto mas pedido : {top} ({veces:,} pedidos)")
    lineas += [
        "",
        "Punto 4 - cruce con persona",
        f"  validos con persona OK : {m.validos_con_persona_ok:,}",
        f"  descartados            : {m.descartados_por_persona:,}",
        f"    por nombre           : {m.persona_fallo_nombre:,}",
        f"    por correo           : {m.persona_fallo_correo:,}",
        f"    por edad             : {m.persona_fallo_edad:,}",
        "",
        "Productos entre los validos (pedidos / unidades)",
    ]
    for producto, veces in m.pedidos_por_producto.most_common():
        lineas.append(f"  {producto:<14} {veces:>10,} {m.unidades_por_producto[producto]:>12,}")

    destino = DIR_SALIDA / "resumen_python.txt"
    destino.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print()
    print(f"  Resumen escrito en: {destino}")


# =====================================================================
def main():
    inicio = time.perf_counter()
    DIR_SALIDA.mkdir(parents=True, exist_ok=True)

    titulo("PARTES B y C - Validacion de pedidos con DSL y Regex")
    print(f"  Conexion: {config.USER}@{config.HOST}:{config.PORT}/{config.DATABASE}")
    print(f"  Salidas : {DIR_SALIDA}")

    try:
        conn = psycopg2.connect(**config.DSN)
    except psycopg2.OperationalError as e:
        print("ERROR: no se pudo conectar a PostgreSQL.")
        print(f"       {str(e).strip()}")
        sys.exit(1)

    try:
        conn.set_client_encoding("UTF8")
        m = recorrido_principal(conn)
        filtro_mas_de_dos_unidades(conn)
        informe(m)
        escribir_resumen(m)
    finally:
        conn.close()

    print()
    print(f"Tiempo total: {time.perf_counter() - inicio:.1f} s")


if __name__ == "__main__":
    main()
