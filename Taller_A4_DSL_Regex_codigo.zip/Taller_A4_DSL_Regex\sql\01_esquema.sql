-- =====================================================================
--  A4-LABORATORIO : DSL y Regex en Validacion de Dataset
--  Motor: PostgreSQL 14+   (probado con pgAdmin 4)
--
--  PASO 1 de 3 - Creacion de la base de datos y del esquema.
--
--  COMO EJECUTARLO EN pgAdmin 4:
--    a) Conectese al servidor y abra el Query Tool sobre la base "postgres".
--    b) Ejecute UNICAMENTE el bloque "A" (CREATE DATABASE). PostgreSQL no
--       permite CREATE DATABASE dentro de un bloque transaccional, por eso
--       va separado del resto.
--    c) Refresque el arbol, abra el Query Tool ahora sobre "ubosquebd" y
--       ejecute el bloque "B".
-- =====================================================================


-- ---------------------------------------------------------------------
-- BLOQUE A  (ejecutar conectado a la base "postgres")
-- ---------------------------------------------------------------------
-- El ENCODING UTF8 es obligatorio: el dataset trae tildes y enies
-- ("Microfono", "Camara Web", "Maria"). Con LATIN1 o WIN1252 los nombres
-- se corrompen y las validaciones de Regex arrojan falsos negativos.

-- DROP DATABASE IF EXISTS ubosquebd;

CREATE DATABASE ubosquebd
    WITH ENCODING = 'UTF8'
         LC_COLLATE = 'Spanish_Spain.1252'
         LC_CTYPE   = 'Spanish_Spain.1252'
         TEMPLATE   = template0;

COMMENT ON DATABASE ubosquebd IS 'A4 Laboratorio - DSL y Regex - Compiladores 2026-2';


-- ---------------------------------------------------------------------
-- BLOQUE B  (ejecutar conectado a la base "ubosquebd")
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS persona;


-- Tabla "persona" -----------------------------------------------------
-- Replica la estructura mostrada en el enunciado (id / nombre / correo /
-- edad). Se ampliaron nombre y correo de varchar(20)/varchar(30) a
-- varchar(50)/varchar(80) porque los correos generados para los usuarios
-- referenciados por el dataset de pedidos incluyen el id numerico y
-- superan los 30 caracteres.

CREATE TABLE persona (
    id      INTEGER      NOT NULL,
    nombre  VARCHAR(50)  NOT NULL,
    correo  VARCHAR(80)  NOT NULL,
    edad    INTEGER      NOT NULL,
    CONSTRAINT pk_persona PRIMARY KEY (id)
);

COMMENT ON TABLE  persona        IS 'Usuarios del sistema. Contiene datos validos e invalidos a proposito.';
COMMENT ON COLUMN persona.correo IS 'Debe cumplir ^[\w\.-]+@[\w\.-]+\.\w+$ para considerarse valido.';


-- Tabla "pedidos" -----------------------------------------------------
-- Campos tomados del encabezado de pedidos_dataset.csv:
--     ID, Usuario_ID, Producto, Cantidad, Codigo
-- La relacion pedidos.usuario_id -> persona.id es el punto 4 del
-- laboratorio (cruce de validaciones).

CREATE TABLE pedidos (
    id         INTEGER      NOT NULL,
    usuario_id INTEGER      NOT NULL,
    producto   VARCHAR(60)  NOT NULL,
    cantidad   INTEGER      NOT NULL,
    codigo     VARCHAR(40)  NOT NULL,
    CONSTRAINT pk_pedidos PRIMARY KEY (id)
);

COMMENT ON TABLE  pedidos          IS 'Registros de pedidos. 2.000.000 de filas.';
COMMENT ON COLUMN pedidos.codigo   IS 'Debe cumplir ^[A-Z]{3}-[0-9]{4}-[A-Z]$ para considerarse valido.';
COMMENT ON COLUMN pedidos.producto IS 'Debe iniciar en mayuscula y contener solo letras y espacios.';


-- NOTA SOBRE LA LLAVE FORANEA Y LOS INDICES ---------------------------
-- La FK pedidos.usuario_id -> persona.id y los indices de apoyo NO se
-- declaran aqui a proposito. Con 2.000.000 de filas, validar la FK y
-- mantener los indices durante un COPY masivo multiplica el tiempo de
-- carga. El patron estandar de bulk-load es: crear tablas desnudas,
-- cargar, y recien entonces aplicar restricciones e indices.
--
-- Siguiente paso -> ejecutar python/cargar_datos.py
-- Y despues       -> ejecutar sql/02_restricciones_indices.sql
