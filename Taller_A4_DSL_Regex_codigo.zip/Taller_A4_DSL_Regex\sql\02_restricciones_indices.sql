-- =====================================================================
--  A4-LABORATORIO : DSL y Regex en Validacion de Dataset
--
--  PASO 3 de 3 - Restricciones e indices.
--  Ejecutar conectado a "ubosquebd" DESPUES de haber corrido
--  python/cargar_datos.py
-- =====================================================================


-- Llave foranea -------------------------------------------------------
-- Establece la relacion entre las dos tablas que pide el punto 4 del
-- enunciado. Si esta sentencia falla con "violates foreign key
-- constraint", significa que hay pedidos apuntando a usuarios que no
-- existen: vuelva a generar persona_dataset.csv con GenerarPersonas.java.

ALTER TABLE pedidos
    ADD CONSTRAINT fk_pedidos_persona
    FOREIGN KEY (usuario_id) REFERENCES persona (id);


-- Indices de apoyo ----------------------------------------------------
-- El DSL filtra por cantidad (punto 2.d: "pedidos con mas de 2 unidades")
-- y hace join por usuario_id (punto 4). Sin estos indices, cada consulta
-- sobre 2 millones de filas obliga a un Seq Scan completo.

CREATE INDEX idx_pedidos_cantidad   ON pedidos (cantidad);
CREATE INDEX idx_pedidos_usuario_id ON pedidos (usuario_id);
CREATE INDEX idx_pedidos_producto   ON pedidos (producto);


-- Estadisticas para el planificador -----------------------------------
ANALYZE persona;
ANALYZE pedidos;


-- =====================================================================
--  VERIFICACION - estas consultas deben ejecutarse sin error y sirven
--  como evidencia grafica para el informe (punto 3 de la entrega).
-- =====================================================================

-- V1. Conteo de filas cargadas
SELECT 'persona' AS tabla, COUNT(*) AS filas FROM persona
UNION ALL
SELECT 'pedidos', COUNT(*) FROM pedidos;


-- V2. Muestra de la tabla pedidos
SELECT * FROM pedidos ORDER BY id LIMIT 15;


-- V3. Integridad referencial: debe devolver 0
SELECT COUNT(*) AS pedidos_huerfanos
FROM   pedidos p
LEFT   JOIN persona u ON u.id = p.usuario_id
WHERE  u.id IS NULL;


-- V4. Contraste SQL vs. DSL -------------------------------------------
-- PostgreSQL soporta Regex nativo con el operador ~. Esto permite
-- comprobar desde el motor que los conteos que reporta el DSL en Java y
-- en Python son correctos. Es la mejor evidencia de que la validacion
-- esta bien implementada.

SELECT
    COUNT(*)                                                       AS total,
    COUNT(*) FILTER (WHERE codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$') AS codigo_ok,
    COUNT(*) FILTER (WHERE producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$')         AS producto_ok,
    COUNT(*) FILTER (WHERE cantidad > 0)                           AS cantidad_ok,
    COUNT(*) FILTER (WHERE codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
                       AND producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
                       AND cantidad > 0)                           AS validos
FROM pedidos;


-- V5. Promedio de cantidad y producto mas pedido entre los validos
SELECT ROUND(AVG(cantidad), 4) AS promedio_cantidad
FROM   pedidos
WHERE  codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
  AND  producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
  AND  cantidad > 0;

SELECT producto, COUNT(*) AS veces, SUM(cantidad) AS unidades
FROM   pedidos
WHERE  codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
  AND  producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
  AND  cantidad > 0
GROUP  BY producto
ORDER  BY veces DESC
LIMIT  10;


-- V6. Punto 4.b - pedidos descartados porque la PERSONA es invalida
--     (pedido valido, pero su usuario tiene nombre, correo o edad malos)
SELECT COUNT(*) AS descartados_por_usuario_invalido
FROM   pedidos p
JOIN   persona u ON u.id = p.usuario_id
WHERE  p.codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
  AND  p.producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
  AND  p.cantidad > 0
  AND  NOT ( u.nombre ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
        AND  u.correo ~ '^[\w\.-]+@[\w\.-]+\.\w+$'
        AND  u.edad  >= 18 );
