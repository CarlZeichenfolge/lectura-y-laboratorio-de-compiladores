-- =====================================================================
--  A4-LABORATORIO : consultas listas para las CAPTURAS del informe
--
--  Cada bloque esta pensado para producir UN SOLO cuadro de resultados,
--  de modo que baste una captura de pantalla por bloque.
--
--  COMO EJECUTARLAS EN pgAdmin 4
--  -----------------------------
--   1. En el panel izquierdo despliegue:
--        Servers > (su servidor) > Databases > ubosquebd
--      y haga clic sobre "ubosquebd" para seleccionarla.
--      IMPORTANTE: debe quedar seleccionada ubosquebd, no "postgres".
--   2. Menu superior: Tools > Query Tool  (o el icono del rayo).
--   3. Copie UN bloque, peguelo en el Query Tool y pulse F5.
--   4. El resultado aparece abajo, en la pestania "Data Output".
--
--  Si pega varios bloques a la vez y pulsa F5, pgAdmin ejecuta todos
--  pero solo MUESTRA el resultado del ultimo. Por eso van de a uno.
-- =====================================================================


-- =====================================================================
--  CAPTURA 6 - Conteo de filas e integridad referencial
--  Responde: se cargo todo? quedo bien la llave foranea?
--  Esperado: 1.263.988 / 2.000.000 / 0
-- =====================================================================

SELECT 'persona (usuarios)' AS tabla, COUNT(*) AS filas FROM persona
UNION ALL
SELECT 'pedidos',            COUNT(*) FROM pedidos
UNION ALL
SELECT 'PEDIDOS HUERFANOS',  COUNT(*)
FROM   pedidos p
LEFT   JOIN persona u ON u.id = p.usuario_id
WHERE  u.id IS NULL;


-- =====================================================================
--  CAPTURA 13 - Contraste de las validaciones desde el propio motor
--
--  PostgreSQL soporta expresiones regulares de forma nativa con el
--  operador "~". Esta consulta aplica exactamente los mismos patrones
--  que Java y Python, de modo que sirve para demostrar que las tres
--  implementaciones coinciden.
--
--  Esperado: 2.000.000 / 1.519.879 / 1.601.240 / 2.000.000 / 1.216.968
--            y promedio 5.4985
-- =====================================================================

SELECT
    COUNT(*) AS total,

    COUNT(*) FILTER (
        WHERE codigo ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
    ) AS codigo_ok,

    COUNT(*) FILTER (
        WHERE producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
    ) AS producto_ok,

    COUNT(*) FILTER (WHERE cantidad > 0) AS cantidad_ok,

    COUNT(*) FILTER (
        WHERE codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
          AND producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
          AND cantidad > 0
    ) AS validos,

    ROUND(AVG(cantidad) FILTER (
        WHERE codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
          AND producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
          AND cantidad > 0
    ), 4) AS promedio_cantidad

FROM pedidos;


-- =====================================================================
--  CAPTURA 13-bis (opcional) - Producto mas pedido entre los validos
--  Esperado: Cable HDMI encabeza con 64.429 pedidos.
--  Note que "Camara Web" NO aparece: su codigo empieza por CAM con
--  tilde, y la A acentuada no pertenece al rango ASCII [A-Z].
-- =====================================================================

SELECT producto,
       COUNT(*)       AS pedidos,
       SUM(cantidad)  AS unidades
FROM   pedidos
WHERE  codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
  AND  producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
  AND  cantidad > 0
GROUP  BY producto
ORDER  BY pedidos DESC;


-- =====================================================================
--  CAPTURA 11 - Punto 4.b: pedidos descartados porque la PERSONA
--  asociada tiene datos incorrectos.
--
--  Devuelve el total y el desglose por campo defectuoso. Una misma
--  persona puede fallar en varios campos, por eso el desglose no suma
--  el total.
--
--  Esperado: 363.929 descartados
--            (nombre 169.784 / correo 170.204 / edad 72.892)
-- =====================================================================

WITH pedidos_validos AS (
    SELECT p.id, u.nombre, u.correo, u.edad
    FROM   pedidos p
    JOIN   persona u ON u.id = p.usuario_id
    WHERE  p.codigo   ~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
      AND  p.producto ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$'
      AND  p.cantidad > 0
),
clasificados AS (
    SELECT
        (nombre ~ '^[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]*$') AS nombre_ok,
        (correo ~ '^[\w\.-]+@[\w\.-]+\.\w+$')               AS correo_ok,
        (edad >= 18)                                        AS edad_ok
    FROM pedidos_validos
)
SELECT
    COUNT(*)                                                   AS pedidos_validos,
    COUNT(*) FILTER (WHERE nombre_ok AND correo_ok AND edad_ok) AS persona_ok,
    COUNT(*) FILTER (WHERE NOT (nombre_ok AND correo_ok AND edad_ok)) AS descartados,
    COUNT(*) FILTER (WHERE NOT nombre_ok)                      AS falla_nombre,
    COUNT(*) FILTER (WHERE NOT correo_ok)                      AS falla_correo,
    COUNT(*) FILTER (WHERE NOT edad_ok)                        AS falla_edad
FROM clasificados;


-- =====================================================================
--  EXTRA (opcional) - Ejemplos concretos de codigos invalidos.
--  Muy util para ilustrar la pregunta de reflexion 3.a.
-- =====================================================================

SELECT codigo, producto, COUNT(*) AS veces
FROM   pedidos
WHERE  codigo !~ '^[A-Z]{3}-[0-9]{4}-[A-Z]$'
GROUP  BY codigo, producto
ORDER  BY veces DESC
LIMIT  15;
